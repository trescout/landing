---
title: "Human Effort"
type: sozluk
category: "dev"
aliases:
  - "Human Effort"
url: "https://trescout.com/dictionary/human-effort/"
---

# Human Effort 

> [!NOTE] Tanım
> Bir projenin veya görevin tamamlanması için insanların harcadığı zihinsel ve fiziksel çabanın bütünüdür.

## İngilizce Açıklama
It is the totality of mental and physical effort made by people to complete a project or task.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/human-effort/)*
