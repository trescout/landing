---
title: "Emulator"
type: sozluk
category: "dev"
aliases:
  - "Emulator"
url: "https://trescout.com/dictionary/emulator/"
---

# Emulator 

> [!NOTE] Tanım
> Bir bilgisayarın veya oyun konsolunun donanımını yazılımsal olarak taklit ederek, başka cihazlara ait programları çalıştırmanızı sağlayan bir araçtır.

## İngilizce Açıklama
It is a tool that allows you to run programs on other devices by software emulating the hardware of a computer or game console.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/emulator/)*
