---
title: "Agentic AI"
type: sozluk
category: "ai"
aliases:
  - "Agentic AI"
url: "https://trescout.com/dictionary/agentic-ai/"
---

# Agentic AI 

> [!NOTE] Tanım
> Yapay zekanın sadece metin üretmek yerine hedeflere ulaşmak için inisiyatif almasıdır.

## İngilizce Açıklama
Artificial intelligence takes initiative to achieve goals instead of just producing text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agentic-ai/)*
