---
title: "ADHD"
type: sozluk
category: "ai"
aliases:
  - "ADHD"
  - "Attention Deficit Hyperactivity Disorder"
url: "https://trescout.com/dictionary/adhd/"
---

# ADHD (Attention Deficit Hyperactivity Disorder)

> [!NOTE] Tanım
> Dikkat dağınıklığı, aşırı hareketlilik ve dürtüsellik ile karakterize edilen nörolojik bir durumdur.

## İngilizce Açıklama
It is a neurological condition characterized by distractibility, hyperactivity and impulsivity.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/adhd/)*
