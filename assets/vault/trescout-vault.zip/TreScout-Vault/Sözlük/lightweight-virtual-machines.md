---
title: "Lightweight Virtual Machines"
type: sozluk
category: "dev"
aliases:
  - "Lightweight Virtual Machines"
url: "https://trescout.com/dictionary/lightweight-virtual-machines/"
---

# Lightweight Virtual Machines 

> [!NOTE] Tanım
> Sadece gerekli kaynakları kullanarak hızlıca çalışan, çok az yer kaplayan küçük sanal bilgisayarlar.

## İngilizce Açıklama
Small virtual computers that run quickly using only the necessary resources and take up very little space.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/lightweight-virtual-machines/)*
