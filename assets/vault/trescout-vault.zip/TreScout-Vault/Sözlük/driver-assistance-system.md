---
title: "Driver Assistance System"
type: sozluk
category: "ai"
aliases:
  - "Driver Assistance System"
  - "Advanced Driver Assistance Systems (ADAS)"
url: "https://trescout.com/dictionary/driver-assistance-system/"
---

# Driver Assistance System (Advanced Driver Assistance Systems (ADAS))

> [!NOTE] Tanım
> Sürüş sırasında güvenliği artırmak için sürücüyü uyaran veya aracı otomatik kontrol eden akıllı yardımcı teknolojilerdir.

## İngilizce Açıklama
They are smart assistive technologies that warn the driver or automatically control the vehicle to increase safety while driving.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/driver-assistance-system/)*
