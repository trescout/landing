---
title: "Linear Scalability"
type: sozluk
category: "data"
aliases:
  - "Linear Scalability"
url: "https://trescout.com/dictionary/linear-scalability/"
---

# Linear Scalability 

> [!NOTE] Tanım
> Sisteme eklenen kaynak miktarı arttıkça, performansın da aynı oranda düzenli bir şekilde artması durumu.

## İngilizce Açıklama
As the amount of resources added to the system increases, the performance increases at the same rate.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/linear-scalability/)*
