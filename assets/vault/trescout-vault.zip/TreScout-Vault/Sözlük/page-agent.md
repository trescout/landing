---
title: "Page Agent"
type: sozluk
category: "ai"
aliases:
  - "Page Agent"
url: "https://trescout.com/dictionary/page-agent/"
---

# Page Agent 

> [!NOTE] Tanım
> İnternet sayfalarını tarayıp kullanıcı adına tıklama veya veri girişi gibi işlemler yapan özel bir yapay zekâ yardımcısıdır.

## İngilizce Açıklama
It is a special artificial intelligence assistant that scans web pages and performs actions such as clicking or entering data on behalf of the user.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/page-agent/)*
