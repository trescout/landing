---
title: "PaaS"
type: sozluk
category: "dev"
aliases:
  - "PaaS"
  - "Platform as a Service"
url: "https://trescout.com/dictionary/paas/"
---

# PaaS (Platform as a Service)

> [!NOTE] Tanım
> Yazılımcıların uygulamalarını geliştirmeleri ve yayınlamaları için gerekli altyapının hazır sunulmasıdır.

## İngilizce Açıklama
It is the provision of the necessary infrastructure for software developers to develop and publish their applications.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/paas/)*
