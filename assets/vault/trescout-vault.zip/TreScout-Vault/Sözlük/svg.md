---
title: "SVG"
type: sozluk
category: "dev"
aliases:
  - "SVG"
  - "Scalable Vector Graphics"
url: "https://trescout.com/dictionary/svg/"
---

# SVG (Scalable Vector Graphics)

> [!NOTE] Tanım
> Matematiksel formüllerle oluşturulan ve kalitesi bozulmadan istenildiği kadar büyütülebilen dijital görsel dosyasıdır.

## İngilizce Açıklama
It is a digital image file created with mathematical formulas and can be enlarged as desired without losing quality.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/svg/)*
