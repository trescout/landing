---
title: "AGI"
type: sozluk
category: "ai"
aliases:
  - "AGI"
  - "Artificial General Intelligence"
url: "https://trescout.com/dictionary/agi/"
---

# AGI (Artificial General Intelligence)

> [!NOTE] Tanım
> İnsan seviyesinde veya üzerinde zeka sergileyen yapay zekâ hedefidir.

## İngilizce Açıklama
It is the goal of AI that exhibits human-level or above intelligence.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agi/)*
