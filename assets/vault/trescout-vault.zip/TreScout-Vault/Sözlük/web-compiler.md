---
title: "Web Compiler"
type: sozluk
category: "dev"
aliases:
  - "Web Compiler"
url: "https://trescout.com/dictionary/web-compiler/"
---

# Web Compiler 

> [!NOTE] Tanım
> Kodlarınızı bilgisayarınıza hiçbir şey kurmadan, doğrudan internet tarayıcınız üzerinden çalıştırılabilir hale getiren araçtır.

## İngilizce Açıklama
It is a tool that makes your codes executable directly through your internet browser, without installing anything on your computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/web-compiler/)*
