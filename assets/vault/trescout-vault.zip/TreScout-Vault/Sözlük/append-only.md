---
title: "Append-only"
type: sozluk
category: "data"
aliases:
  - "Append-only"
url: "https://trescout.com/dictionary/append-only/"
---

# Append-only 

> [!NOTE] Tanım
> Verilerin sadece sona eklenebildiği, değiştirilemediği veya silinemediği bir kayıt yöntemidir.

## İngilizce Açıklama
Verilerin sadece sona eklenebildiği, değiştirilemediği veya silinemediği bir kayıt yöntemidir.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/append-only/)*
