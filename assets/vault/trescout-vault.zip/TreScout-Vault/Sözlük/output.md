---
title: "Output"
type: sozluk
category: "dev"
aliases:
  - "Output"
url: "https://trescout.com/dictionary/output/"
---

# Output 

> [!NOTE] Tanım
> Bir bilgisayar programının veya yapay zekâ sisteminin işlem sonucunda ürettiği veridir.

## İngilizce Açıklama
It is the data produced by a computer program or artificial intelligence system as a result of the process.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/output/)*
