---
title: "CEO"
type: sozluk
category: "dev"
aliases:
  - "CEO"
  - "Chief Executive Officer"
url: "https://trescout.com/dictionary/ceo/"
---

# CEO (Chief Executive Officer)

> [!NOTE] Tanım
> Bir şirketin tüm operasyonlarını ve stratejik kararlarını yöneten en üst düzey yetkilidir.

## İngilizce Açıklama
He is the highest-level official who manages all operations and strategic decisions of a company.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/ceo/)*
