---
title: "GIS"
type: sozluk
category: "data"
aliases:
  - "GIS"
  - "Geographic Information System"
url: "https://trescout.com/dictionary/gis/"
---

# GIS (Geographic Information System)

> [!NOTE] Tanım
> Dünya üzerindeki coğrafi verileri toplayan, analiz eden ve harita üzerinde görselleştiren dijital sistem.

## İngilizce Açıklama
A digital system that collects, analyzes and visualizes geographical data on the world on a map.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/gis/)*
