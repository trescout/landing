---
title: "Computer Use"
type: sozluk
category: "ai"
aliases:
  - "Computer Use"
url: "https://trescout.com/dictionary/computer-use/"
---

# Computer Use 

> [!NOTE] Tanım
> Yapay zekanın tıpkı bir insan gibi ekranı görüp fare ve klavye kullanarak bilgisayarı yönetebilme yeteneğidir.

## İngilizce Açıklama
It is the ability of artificial intelligence to see the screen and manage the computer using a mouse and keyboard, just like a human.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/computer-use/)*
