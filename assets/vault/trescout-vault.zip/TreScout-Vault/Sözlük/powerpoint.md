---
title: "PowerPoint"
type: sozluk
category: "dev"
aliases:
  - "PowerPoint"
url: "https://trescout.com/dictionary/powerpoint/"
---

# PowerPoint 

> [!NOTE] Tanım
> Bilgileri görsel slaytlar halinde sunmanızı sağlayan bir sunum hazırlama programıdır.

## İngilizce Açıklama
It is a presentation preparation program that allows you to present information in visual slides.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/powerpoint/)*
