---
title: "Spec-driven Development"
type: sozluk
category: "dev"
aliases:
  - "Spec-driven Development"
url: "https://trescout.com/dictionary/spec-driven-development/"
---

# Spec-driven Development 

> [!NOTE] Tanım
> Yazılımı kodlamaya başlamadan önce tüm detayların ve kuralların önceden belirlenmiş bir belgeye göre yapılması.

## İngilizce Açıklama
Before starting to code the software, all the details and rules are made according to a predetermined document.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/spec-driven-development/)*
