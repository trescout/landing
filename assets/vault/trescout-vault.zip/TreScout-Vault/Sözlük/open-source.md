---
title: "Open Source"
type: sozluk
category: "dev"
aliases:
  - "Open Source"
url: "https://trescout.com/dictionary/open-source/"
---

# Open Source 

> [!NOTE] Tanım
> Kaynak kodları herkesin erişimine ve geliştirmesine açık olan yazılımlardır.

## İngilizce Açıklama
They are software whose source codes are open to everyone to access and develop.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/open-source/)*
