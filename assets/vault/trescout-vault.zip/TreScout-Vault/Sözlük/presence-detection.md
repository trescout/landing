---
title: "Presence Detection"
type: sozluk
category: "ai"
aliases:
  - "Presence Detection"
url: "https://trescout.com/dictionary/presence-detection/"
---

# Presence Detection 

> [!NOTE] Tanım
> Bir ortamda insan varlığını sensörler veya yazılım yardımıyla tespit eden teknolojidir.

## İngilizce Açıklama
It is a technology that detects human presence in an environment with the help of sensors or software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/presence-detection/)*
