---
title: "Assets"
type: sozluk
category: "dev"
aliases:
  - "Assets"
url: "https://trescout.com/dictionary/assets/"
---

# Assets 

> [!NOTE] Tanım
> Bir projeyi oluşturan tüm dijital parçaların bütünüdür.

## İngilizce Açıklama
It is the whole of all digital parts that make up a project.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/assets/)*
