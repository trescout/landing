---
title: "Containers"
type: sozluk
category: "dev"
aliases:
  - "Containers"
url: "https://trescout.com/dictionary/containers/"
---

# Containers 

> [!NOTE] Tanım
> Bir yazılımın çalışması için gereken her şeyi içinde barındıran, farklı ortamlarda sorunsuz taşınabilen hafif paketlerdir.

## İngilizce Açıklama
They are lightweight packages that contain everything required for a software to run and can be moved to different environments without any problems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/containers/)*
