---
title: "ETF"
type: sozluk
category: "data"
aliases:
  - "ETF"
  - "Exchange Traded Fund"
url: "https://trescout.com/dictionary/etf/"
---

# ETF (Exchange Traded Fund)

> [!NOTE] Tanım
> Birçok farklı hisse senedini veya varlığı tek bir paket halinde borsada alıp satmanızı sağlayan yatırım aracıdır.

## İngilizce Açıklama
It is an investment tool that allows you to buy and sell many different stocks or assets on the stock exchange in a single package.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/etf/)*
