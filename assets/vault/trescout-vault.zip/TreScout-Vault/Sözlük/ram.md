---
title: "RAM"
type: sozluk
category: "data"
aliases:
  - "RAM"
  - "Random Access Memory"
url: "https://trescout.com/dictionary/ram/"
---

# RAM (Random Access Memory)

> [!NOTE] Tanım
> Bilgisayarın aktif olarak kullandığı verileri hızlıca okuyup yazdığı geçici hafıza birimi.

## İngilizce Açıklama
A temporary memory unit where the computer quickly reads and writes the data it actively uses.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/ram/)*
