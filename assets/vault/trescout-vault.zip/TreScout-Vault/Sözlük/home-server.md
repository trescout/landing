---
title: "Home Server"
type: sozluk
category: "dev"
aliases:
  - "Home Server"
url: "https://trescout.com/dictionary/home-server/"
---

# Home Server 

> [!NOTE] Tanım
> Evdeki cihazların dosya paylaşımı ve medya yönetimi gibi işlerini üstlenen sürekli açık kişisel sunucudur.

## İngilizce Açıklama
It is an always-on personal server that handles tasks such as file sharing and media management of home devices.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/home-server/)*
