---
title: "In-process Database"
type: sozluk
category: "data"
aliases:
  - "In-process Database"
url: "https://trescout.com/dictionary/in-process-database/"
---

# In-process Database 

> [!NOTE] Tanım
> Ayrı bir sunucuya ihtiyaç duymadan doğrudan uygulamanın içinde çalışan hafif veri depolama sistemidir.

## İngilizce Açıklama
It is a lightweight data storage system that runs directly within the application without the need for a separate server.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/in-process-database/)*
