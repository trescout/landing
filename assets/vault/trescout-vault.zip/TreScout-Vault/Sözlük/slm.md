---
title: "SLM"
type: sozluk
category: "ai"
aliases:
  - "SLM"
  - "Small Language Model"
url: "https://trescout.com/dictionary/slm/"
---

# SLM (Small Language Model)

> [!NOTE] Tanım
> Daha az veriyle eğitilmiş, hızlı çalışan ve düşük donanımlarda bile verimli sonuç veren küçük yapay zekâ modelleridir.

## İngilizce Açıklama
They are small artificial intelligence models that are trained with less data, work fast and provide efficient results even on low hardware.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/slm/)*
