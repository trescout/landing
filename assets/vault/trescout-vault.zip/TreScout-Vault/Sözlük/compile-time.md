---
title: "Compile-time"
type: sozluk
category: "dev"
aliases:
  - "Compile-time"
url: "https://trescout.com/dictionary/compile-time/"
---

# Compile-time 

> [!NOTE] Tanım
> Yazılan kodun bilgisayarın anlayacağı dile çevrildiği ve hataların kontrol edildiği hazırlık aşamasıdır.

## İngilizce Açıklama
It is the preparation phase in which the written code is translated into a language that the computer can understand and errors are checked.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/compile-time/)*
