---
title: "Web-based Solutions"
type: sozluk
category: "dev"
aliases:
  - "Web-based Solutions"
url: "https://trescout.com/dictionary/web-based-solutions/"
---

# Web-based Solutions 

> [!NOTE] Tanım
> Bilgisayarınıza herhangi bir kurulum yapmadan, sadece internet tarayıcısı üzerinden erişip kullanabildiğiniz yazılım hizmetleridir.

## İngilizce Açıklama
They are software services that you can access and use only via an internet browser, without any installation on your computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/web-based-solutions/)*
