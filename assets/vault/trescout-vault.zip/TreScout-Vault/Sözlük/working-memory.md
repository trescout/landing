---
title: "Working Memory"
type: sozluk
category: "ai"
aliases:
  - "Working Memory"
url: "https://trescout.com/dictionary/working-memory/"
---

# Working Memory 

> [!NOTE] Tanım
> Yapay zekânın işlem sırasında bilgileri geçici olarak tuttuğu kısa süreli hafıza alanıdır.

## İngilizce Açıklama
It is the short-term memory area where artificial intelligence temporarily keeps information during processing.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/working-memory/)*
