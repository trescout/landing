---
title: "LSP"
type: sozluk
category: "dev"
aliases:
  - "LSP"
  - "Language Server Protocol"
url: "https://trescout.com/dictionary/lsp/"
---

# LSP (Language Server Protocol)

> [!NOTE] Tanım
> Kod yazarken editörünüze akıllı özellikler kazandıran standart bir iletişim protokolüdür.

## İngilizce Açıklama
It is a standard communication protocol that provides smart features to your editor while writing code.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/lsp/)*
