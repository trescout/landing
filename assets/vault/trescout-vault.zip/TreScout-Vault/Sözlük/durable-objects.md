---
title: "Durable Objects"
type: sozluk
category: "dev"
aliases:
  - "Durable Objects"
url: "https://trescout.com/dictionary/durable-objects/"
---

# Durable Objects 

> [!NOTE] Tanım
> İnternet üzerinde sürekli çalışan ve durumunu kaybetmeden veri saklayabilen küçük yazılım birimleridir.

## İngilizce Açıklama
They are small software units that run continuously on the Internet and can store data without losing their state.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/durable-objects/)*
