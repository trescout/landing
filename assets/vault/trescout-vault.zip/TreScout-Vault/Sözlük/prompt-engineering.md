---
title: "Prompt Engineering"
type: sozluk
category: "ai"
aliases:
  - "Prompt Engineering"
url: "https://trescout.com/dictionary/prompt-engineering/"
---

# Prompt Engineering 

> [!NOTE] Tanım
> Yapay zekadan en iyi sonucu almak için verilen komutları optimize etme sanatıdır.

## İngilizce Açıklama
It is the art of optimizing the commands given to get the best results from artificial intelligence.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/prompt-engineering/)*
