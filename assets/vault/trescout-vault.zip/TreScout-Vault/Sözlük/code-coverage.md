---
title: "Code Coverage"
type: sozluk
category: "dev"
aliases:
  - "Code Coverage"
url: "https://trescout.com/dictionary/code-coverage/"
---

# Code Coverage 

> [!NOTE] Tanım
> Yazılım testlerinin, yazılan kodun ne kadarlık bir kısmını gerçekten çalıştırıp kontrol ettiğini ölçen bir metrik.

## İngilizce Açıklama
A metric that measures how much of the written code software tests actually run and check.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/code-coverage/)*
