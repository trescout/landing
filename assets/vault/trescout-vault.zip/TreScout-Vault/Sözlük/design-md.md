---
title: "DESIGN.md"
type: sozluk
category: "dev"
aliases:
  - "DESIGN.md"
url: "https://trescout.com/dictionary/design-md/"
---

# DESIGN.md 

> [!NOTE] Tanım
> Bir yazılım projesinin mimari kararlarını ve tasarım mantığını açıklayan dokümantasyon dosyasıdır.

## İngilizce Açıklama
It is a documentation file that explains the architectural decisions and design logic of a software project.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/design-md/)*
