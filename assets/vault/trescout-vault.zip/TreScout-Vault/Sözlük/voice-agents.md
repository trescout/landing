---
title: "Voice Agents"
type: sozluk
category: "ai"
aliases:
  - "Voice Agents"
url: "https://trescout.com/dictionary/voice-agents/"
---

# Voice Agents 

> [!NOTE] Tanım
> Kullanıcıyla sesli iletişim kuran, soruları yanıtlayan ve komutları yerine getiren yapay zekâ asistanlarıdır.

## İngilizce Açıklama
They are artificial intelligence assistants that communicate with the user by voice, answer questions and carry out commands.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/voice-agents/)*
