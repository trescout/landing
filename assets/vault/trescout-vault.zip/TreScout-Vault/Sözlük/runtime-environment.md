---
title: "Runtime Environment"
type: sozluk
category: "dev"
aliases:
  - "Runtime Environment"
url: "https://trescout.com/dictionary/runtime-environment/"
---

# Runtime Environment 

> [!NOTE] Tanım
> Bir yazılımın bilgisayarda çalışabilmesi için ihtiyaç duyduğu temel destekleyici ortam.

## İngilizce Açıklama
The basic supporting environment that a software needs to run on a computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/runtime-environment/)*
