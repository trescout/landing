---
title: "Model Context Protocol"
type: sozluk
category: "ai"
aliases:
  - "Model Context Protocol"
  - "MCP"
url: "https://trescout.com/dictionary/model-context-protocol/"
---

# Model Context Protocol (MCP)

> [!NOTE] Tanım
> Yapay zekâ sistemlerinin verilerle ve araçlarla güvenli bir şekilde konuşmasını sağlayan ortak bir dil.

## İngilizce Açıklama
A common language that allows AI systems to talk to data and tools securely.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/model-context-protocol/)*
