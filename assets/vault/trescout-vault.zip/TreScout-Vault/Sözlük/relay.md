---
title: "Relay"
type: sozluk
category: "dev"
aliases:
  - "Relay"
url: "https://trescout.com/dictionary/relay/"
---

# Relay 

> [!NOTE] Tanım
> Veriyi bir noktadan diğerine aktararak sinyalin ulaşamadığı yerlere taşıyan veya bağlantıyı köprüleyen sistemdir.

## İngilizce Açıklama
It is a system that transfers data from one point to another and carries it to places where the signal cannot reach or bridges the connection.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/relay/)*
