---
title: "SQL Client"
type: sozluk
category: "data"
aliases:
  - "SQL Client"
url: "https://trescout.com/dictionary/sql-client/"
---

# SQL Client 

> [!NOTE] Tanım
> Veritabanındaki bilgileri sorgulamanıza ve yönetmenize yardımcı olan uygulama.

## İngilizce Açıklama
Application that helps you query and manage information in the database.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/sql-client/)*
