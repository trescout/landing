---
title: "Autonomous AI Agent"
type: sozluk
category: "ai"
aliases:
  - "Autonomous AI Agent"
url: "https://trescout.com/dictionary/autonomous-ai-agent/"
---

# Autonomous AI Agent 

> [!NOTE] Tanım
> İnsan müdahalesi olmadan kendi hedeflerini belirleyip karmaşık görevleri uçtan uca yerine getirebilen yazılım sistemidir.

## İngilizce Açıklama
It is a software system that can set its own goals and perform complex tasks end-to-end without human intervention.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/autonomous-ai-agent/)*
