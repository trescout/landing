---
title: "Framework"
type: sozluk
category: "dev"
aliases:
  - "Framework"
url: "https://trescout.com/dictionary/framework/"
---

# Framework 

> [!NOTE] Tanım
> Yazılım geliştirirken işleri hızlandırmak için kullanılan hazır yapı ve kurallar bütünüdür.

## İngilizce Açıklama
It is a set of ready-made structures and rules used to speed up work when developing software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/framework/)*
