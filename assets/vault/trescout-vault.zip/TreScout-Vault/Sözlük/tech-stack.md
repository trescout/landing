---
title: "Tech Stack"
type: sozluk
category: "dev"
aliases:
  - "Tech Stack"
url: "https://trescout.com/dictionary/tech-stack/"
---

# Tech Stack 

> [!NOTE] Tanım
> Bir yazılım projesini inşa etmek için kullanılan tüm diller, veritabanları ve araçların oluşturduğu bütündür.

## İngilizce Açıklama
It is the collection of all languages, databases and tools used to build a software project.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/tech-stack/)*
