---
title: "Zero-shot Voice Cloning"
type: sozluk
category: "ai"
aliases:
  - "Zero-shot Voice Cloning"
url: "https://trescout.com/dictionary/zero-shot-voice-cloning/"
---

# Zero-shot Voice Cloning 

> [!NOTE] Tanım
> Bir kişinin sesini sadece çok kısa bir örnekten yola çıkarak, önceden özel bir eğitim almadan kopyalama teknolojisidir.

## İngilizce Açıklama
It is the technology of transcribing a person's voice using only a very short sample, without any special training beforehand.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/zero-shot-voice-cloning/)*
