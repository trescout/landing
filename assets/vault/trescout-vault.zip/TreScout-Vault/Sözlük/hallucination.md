---
title: "Hallucination"
type: sozluk
category: "ai"
aliases:
  - "Hallucination"
url: "https://trescout.com/dictionary/hallucination/"
---

# Hallucination 

> [!NOTE] Tanım
> Yapay zekanın gerçekte olmayan bilgileri sanki doğruymuş gibi sunmasıdır.

## İngilizce Açıklama
Artificial intelligence presents information that does not actually exist as if it were true.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/hallucination/)*
