---
title: "Specification"
type: sozluk
category: "dev"
aliases:
  - "Specification"
url: "https://trescout.com/dictionary/specification/"
---

# Specification 

> [!NOTE] Tanım
> Bir projenin, yazılımın veya ürünün ne yapması gerektiğini ve hangi kurallara uyması gerektiğini belirten detaylı teknik dokümandır.

## İngilizce Açıklama
It is a detailed technical document that specifies what a project, software or product should do and what rules it must follow.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/specification/)*
