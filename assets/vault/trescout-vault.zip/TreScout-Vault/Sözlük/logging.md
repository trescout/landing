---
title: "Logging"
type: sozluk
category: "dev"
aliases:
  - "Logging"
url: "https://trescout.com/dictionary/logging/"
---

# Logging 

> [!NOTE] Tanım
> Bir programın çalışırken yaptığı işlemleri veya karşılaştığı hataları takip etmek için kronolojik olarak kayıt altına almasıdır.

## İngilizce Açıklama
It is the chronological recording of a program to keep track of the operations it performs or the errors it encounters while it is running.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/logging/)*
