---
title: "Companion"
type: sozluk
category: "ai"
aliases:
  - "Companion"
url: "https://trescout.com/dictionary/companion/"
---

# Companion 

> [!NOTE] Tanım
> Kullanıcıyla sohbet eden, ona yardımcı olan veya günlük işlerinde eşlik eden dijital asistandır.

## İngilizce Açıklama
It is a digital assistant that chats with the user, assists him or her in daily tasks.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/companion/)*
