---
title: "Agent"
type: sozluk
category: "ai"
aliases:
  - "Agent"
url: "https://trescout.com/dictionary/agent/"
---

# Agent 

> [!NOTE] Tanım
> Kendi başına karar verip hedeflenen görevi yerine getirmek için araçları kullanabilen akıllı yazılım birimi.

## İngilizce Açıklama
An intelligent software unit that can make decisions on its own and use tools to perform the targeted task.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agent/)*
