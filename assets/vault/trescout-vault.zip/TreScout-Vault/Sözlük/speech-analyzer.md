---
title: "SpeechAnalyzer"
type: sozluk
category: "ai"
aliases:
  - "SpeechAnalyzer"
url: "https://trescout.com/dictionary/speech-analyzer/"
---

# SpeechAnalyzer 

> [!NOTE] Tanım
> Ses kayıtlarını metne dönüştüren ve bu metindeki duygu, ton veya anlamı çözümleyen bir analiz aracıdır.

## İngilizce Açıklama
It is an analysis tool that converts audio recordings into text and analyzes the emotion, tone or meaning in this text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/speech-analyzer/)*
