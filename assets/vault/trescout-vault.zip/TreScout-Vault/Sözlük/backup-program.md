---
title: "Backup Program"
type: sozluk
category: "data"
aliases:
  - "Backup Program"
url: "https://trescout.com/dictionary/backup-program/"
---

# Backup Program 

> [!NOTE] Tanım
> Dijital verilerinizin bir kopyasını alarak kaybolmalarını önleyen yazılımdır.

## İngilizce Açıklama
It is software that prevents loss of your digital data by making a copy of it.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/backup-program/)*
