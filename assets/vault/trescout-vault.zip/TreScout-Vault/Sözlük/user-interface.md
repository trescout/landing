---
title: "User Interface"
type: sozluk
category: "dev"
aliases:
  - "User Interface"
  - "UI"
url: "https://trescout.com/dictionary/user-interface/"
---

# User Interface (UI)

> [!NOTE] Tanım
> Kullanıcının bir cihaz veya yazılımla etkileşime girmesini sağlayan görsel ekran ve kontrol alanıdır.

## İngilizce Açıklama
It is the visual display and control area that allows the user to interact with a device or software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/user-interface/)*
