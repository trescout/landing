---
title: "Binary"
type: sozluk
category: "dev"
aliases:
  - "Binary"
url: "https://trescout.com/dictionary/binary/"
---

# Binary 

> [!NOTE] Tanım
> Bilgisayarın sadece 0 ve 1 kullanarak anladığı en temel makine dilidir.

## İngilizce Açıklama
It is the most basic machine language that the computer understands using only 0 and 1.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/binary/)*
