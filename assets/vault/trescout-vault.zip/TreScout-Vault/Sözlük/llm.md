---
title: "LLM"
type: sozluk
category: "ai"
aliases:
  - "LLM"
  - "Large Language Model"
url: "https://trescout.com/dictionary/llm/"
---

# LLM (Large Language Model)

> [!NOTE] Tanım
> İnsan dilini anlayan, analiz eden ve metin üretebilen devasa yapay zekâ modelleridir.

## İngilizce Açıklama
They are huge artificial intelligence models that understand human language, analyze it and produce text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/llm/)*
