---
title: "Workflows"
type: sozluk
category: "dev"
aliases:
  - "Workflows"
url: "https://trescout.com/dictionary/workflows/"
---

# Workflows 

> [!NOTE] Tanım
> Bir işin başından sonuna kadar izlediği düzenli ve mantıksal adımlar dizisidir.

## İngilizce Açıklama
It is an orderly and logical sequence of steps that a job follows from beginning to end.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/workflows/)*
