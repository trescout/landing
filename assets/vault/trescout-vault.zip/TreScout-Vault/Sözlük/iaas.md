---
title: "IaaS"
type: sozluk
category: "dev"
aliases:
  - "IaaS"
  - "Infrastructure as a Service"
url: "https://trescout.com/dictionary/iaas/"
---

# IaaS (Infrastructure as a Service)

> [!NOTE] Tanım
> İnternet üzerinden sanal sunucu ve depolama alanı gibi temel donanım kaynaklarının kiralanmasıdır.

## İngilizce Açıklama
It is the rental of basic hardware resources such as virtual servers and storage space over the internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/iaas/)*
