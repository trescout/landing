---
title: "Data Logger"
type: sozluk
category: "data"
aliases:
  - "Data Logger"
url: "https://trescout.com/dictionary/data-logger/"
---

# Data Logger 

> [!NOTE] Tanım
> Sensörlerden gelen verileri belirli aralıklarla kaydedip depolayan elektronik cihazdır.

## İngilizce Açıklama
It is an electronic device that records and stores data from sensors at regular intervals.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/data-logger/)*
