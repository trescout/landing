---
title: "Speaker Diarization"
type: sozluk
category: "ai"
aliases:
  - "Speaker Diarization"
url: "https://trescout.com/dictionary/speaker-diarization/"
---

# Speaker Diarization 

> [!NOTE] Tanım
> Ses kaydındaki konuşmaların kimin tarafından yapıldığını ayırt ederek metin üzerinde konuşmacıları etiketleme sürecidir.

## İngilizce Açıklama
It is the process of labeling speakers on the text by distinguishing who made the speeches in the audio recording.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/speaker-diarization/)*
