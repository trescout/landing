---
title: "Continuous Deployment"
type: sozluk
category: "dev"
aliases:
  - "Continuous Deployment"
  - "CD"
url: "https://trescout.com/dictionary/continuous-deployment/"
---

# Continuous Deployment (CD)

> [!NOTE] Tanım
> Testi başarıyla geçen kodların hiçbir insan müdahalesi olmadan otomatik olarak canlıya alınması.

## İngilizce Açıklama
Codes that pass the test automatically go live without any human intervention.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/continuous-deployment/)*
