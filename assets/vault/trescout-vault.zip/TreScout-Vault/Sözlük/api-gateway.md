---
title: "API Gateway"
type: sozluk
category: "dev"
aliases:
  - "API Gateway"
url: "https://trescout.com/dictionary/api-gateway/"
---

# API Gateway 

> [!NOTE] Tanım
> Dış dünyadan gelen tüm istekleri karşılayan, bunları doğru yerlere yönlendiren ve güvenlik kontrollerini yapan merkezi bir giriş kapısıdır.

## İngilizce Açıklama
It is a central entrance gate that meets all requests from the outside world, directs them to the right places and performs security checks.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/api-gateway/)*
