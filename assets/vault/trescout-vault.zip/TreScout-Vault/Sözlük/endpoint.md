---
title: "Endpoint"
type: sozluk
category: "dev"
aliases:
  - "Endpoint"
url: "https://trescout.com/dictionary/endpoint/"
---

# Endpoint 

> [!NOTE] Tanım
> Ağa bağlı olan bilgisayar, telefon veya tablet gibi uç noktadaki cihazlardır.

## İngilizce Açıklama
They are endpoint devices such as a computer, phone or tablet that are connected to the network.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/endpoint/)*
