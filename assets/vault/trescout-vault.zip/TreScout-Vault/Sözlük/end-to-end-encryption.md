---
title: "End-to-End Encryption"
type: sozluk
category: "dev"
aliases:
  - "End-to-End Encryption"
  - "E2EE"
url: "https://trescout.com/dictionary/end-to-end-encryption/"
---

# End-to-End Encryption (E2EE)

> [!NOTE] Tanım
> Mesajların sadece gönderen ve alıcı tarafından okunabildiği, aradaki kimsenin içeriği göremediği bir güvenlik yöntemidir.

## İngilizce Açıklama
It is a security method in which messages can only be read by the sender and the recipient, and no one in between can see the content.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/end-to-end-encryption/)*
