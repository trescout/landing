---
title: "Project Management"
type: sozluk
category: "dev"
aliases:
  - "Project Management"
url: "https://trescout.com/dictionary/project-management/"
---

# Project Management 

> [!NOTE] Tanım
> Belirli bir hedefi gerçekleştirmek için zaman, kaynak ve görevlerin planlanması ve yönetilmesidir.

## İngilizce Açıklama
It is the planning and management of time, resources and tasks to achieve a specific goal.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/project-management/)*
