---
title: "Adblocker"
type: sozluk
category: "dev"
aliases:
  - "Adblocker"
url: "https://trescout.com/dictionary/adblocker/"
---

# Adblocker 

> [!NOTE] Tanım
> İnternet tarayıcınızda reklamların görünmesini engelleyen bir yazılım eklentisidir.

## İngilizce Açıklama
It is a software plug-in that prevents ads from appearing in your internet browser.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/adblocker/)*
