---
title: "Agentic Workflows"
type: sozluk
category: "ai"
aliases:
  - "Agentic Workflows"
url: "https://trescout.com/dictionary/agentic-workflows/"
---

# Agentic Workflows 

> [!NOTE] Tanım
> Yapay zekâ araçlarının insan müdahalesi olmadan kendi kararlarını verip bir işi uçtan uca tamamlamasıdır.

## İngilizce Açıklama
Artificial intelligence tools make their own decisions and complete a job end-to-end without human intervention.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agentic-workflows/)*
