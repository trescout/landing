---
title: "User Identifiers"
type: sozluk
category: "dev"
aliases:
  - "User Identifiers"
url: "https://trescout.com/dictionary/user-identifiers/"
---

# User Identifiers 

> [!NOTE] Tanım
> Dijital sistemlerde her bir kullanıcıyı birbirinden ayırt etmek için kullanılan benzersiz kimlik belirteçleridir.

## İngilizce Açıklama
They are unique identity markers used to distinguish each user in digital systems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/user-identifiers/)*
