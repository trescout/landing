---
title: "Distributed"
type: sozluk
category: "dev"
aliases:
  - "Distributed"
url: "https://trescout.com/dictionary/distributed/"
---

# Distributed 

> [!NOTE] Tanım
> Bir işin tek bir merkez yerine ağa bağlı birden fazla cihaz arasında paylaştırılarak yapılmasıdır.

## İngilizce Açıklama
It is the sharing of a job among multiple devices connected to the network instead of a single center.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/distributed/)*
