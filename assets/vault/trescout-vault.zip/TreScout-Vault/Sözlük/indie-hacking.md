---
title: "Indie Hacking"
type: sozluk
category: "dev"
aliases:
  - "Indie Hacking"
url: "https://trescout.com/dictionary/indie-hacking/"
---

# Indie Hacking 

> [!NOTE] Tanım
> Büyük şirketlerin desteği olmadan, tek başına veya çok küçük ekiplerle dijital ürünler geliştirip piyasaya sürme kültürüdür.

## İngilizce Açıklama
It is the culture of developing and launching digital products alone or with very small teams, without the support of large companies.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/indie-hacking/)*
