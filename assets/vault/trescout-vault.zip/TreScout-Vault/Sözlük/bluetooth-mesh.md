---
title: "Bluetooth Mesh"
type: sozluk
category: "dev"
aliases:
  - "Bluetooth Mesh"
url: "https://trescout.com/dictionary/bluetooth-mesh/"
---

# Bluetooth Mesh 

> [!NOTE] Tanım
> Birden fazla cihazın birbirine bağlanarak geniş bir alanda ağ kurmasını sağlayan kablosuz iletişim teknolojisi.

## İngilizce Açıklama
Wireless communication technology that allows multiple devices to connect to each other and establish a network in a wide area.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bluetooth-mesh/)*
