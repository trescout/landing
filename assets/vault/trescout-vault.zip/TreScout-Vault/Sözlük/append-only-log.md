---
title: "Append-only log"
type: sozluk
category: "data"
aliases:
  - "Append-only log"
url: "https://trescout.com/dictionary/append-only-log/"
---

# Append-only log 

> [!NOTE] Tanım
> Registre sécurisé où les anciennes données ne peuvent pas être modifiées, et où seules de nouvelles informations peuvent être ajoutées à la fin.

## İngilizce Açıklama
Secure ledger where old data cannot be modified and only new information can be appended at the end.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/append-only-log/)*
