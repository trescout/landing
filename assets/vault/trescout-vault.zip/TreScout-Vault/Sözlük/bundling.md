---
title: "Bundling"
type: sozluk
category: "dev"
aliases:
  - "Bundling"
url: "https://trescout.com/dictionary/bundling/"
---

# Bundling 

> [!NOTE] Tanım
> Web sitelerinin çalışması için gereken çok sayıda küçük kod dosyasının birleştirilerek tek bir paket haline getirilmesidir.

## İngilizce Açıklama
It is the combination of many small code files required for websites to work and turned into a single package.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bundling/)*
