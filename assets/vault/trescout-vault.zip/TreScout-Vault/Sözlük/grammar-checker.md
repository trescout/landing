---
title: "Grammar Checker"
type: sozluk
category: "ai"
aliases:
  - "Grammar Checker"
url: "https://trescout.com/dictionary/grammar-checker/"
---

# Grammar Checker 

> [!NOTE] Tanım
> Yazılı metinlerdeki dil bilgisi, imla ve noktalama hatalarını otomatik olarak tespit edip düzelten yazılımlardır.

## İngilizce Açıklama
They are software that automatically detects and corrects grammar, spelling and punctuation errors in written texts.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/grammar-checker/)*
