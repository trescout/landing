---
title: "Chrome DevTools"
type: sozluk
category: "dev"
aliases:
  - "Chrome DevTools"
url: "https://trescout.com/dictionary/chrome-devtools/"
---

# Chrome DevTools 

> [!NOTE] Tanım
> Web tarayıcısının içine gömülü, web sitelerinin kodlarını incelemeye ve hataları düzeltmeye yarayan geliştirici aracıdır.

## İngilizce Açıklama
It is a developer tool embedded in the web browser that helps examine the codes of websites and fix errors.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/chrome-devtools/)*
