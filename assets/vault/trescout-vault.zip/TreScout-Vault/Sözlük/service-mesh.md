---
title: "Service Mesh"
type: sozluk
category: "dev"
aliases:
  - "Service Mesh"
url: "https://trescout.com/dictionary/service-mesh/"
---

# Service Mesh 

> [!NOTE] Tanım
> Karmaşık yazılım sistemlerinde, farklı servislerin birbirleriyle güvenli ve düzenli iletişim kurmasını sağlayan bir altyapı katmanıdır.

## İngilizce Açıklama
It is an infrastructure layer that enables different services to communicate with each other securely and regularly in complex software systems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/service-mesh/)*
