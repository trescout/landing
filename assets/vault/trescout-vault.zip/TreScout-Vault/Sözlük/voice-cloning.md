---
title: "Voice Cloning"
type: sozluk
category: "ai"
aliases:
  - "Voice Cloning"
url: "https://trescout.com/dictionary/voice-cloning/"
---

# Voice Cloning 

> [!NOTE] Tanım
> Belirli bir kişinin sesini taklit ederek yeni cümleler kuran yapay zekâ teknolojisidir.

## İngilizce Açıklama
It is an artificial intelligence technology that creates new sentences by imitating the voice of a specific person.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/voice-cloning/)*
