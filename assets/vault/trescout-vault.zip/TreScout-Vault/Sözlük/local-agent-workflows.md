---
title: "Local Agent Workflows"
type: sozluk
category: "ai"
aliases:
  - "Local Agent Workflows"
url: "https://trescout.com/dictionary/local-agent-workflows/"
---

# Local Agent Workflows 

> [!NOTE] Tanım
> İnternete ihtiyaç duymadan, doğrudan kendi bilgisayarınızda çalışan otonom görev süreçleridir.

## İngilizce Açıklama
They are autonomous task processes that run directly on your own computer, without the need for the Internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/local-agent-workflows/)*
