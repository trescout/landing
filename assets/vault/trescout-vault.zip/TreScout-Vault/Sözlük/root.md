---
title: "Root"
type: sozluk
category: "dev"
aliases:
  - "Root"
url: "https://trescout.com/dictionary/root/"
---

# Root 

> [!NOTE] Tanım
> Bir işletim sistemi üzerinde tüm dosyalara, ayarlara ve komutlara sınırsız erişim sağlayan en üst düzey yetkili hesaptır.

## İngilizce Açıklama
It is the highest level authorized account that provides unlimited access to all files, settings and commands on an operating system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/root/)*
