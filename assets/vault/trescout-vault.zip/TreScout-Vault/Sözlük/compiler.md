---
title: "Compiler"
type: sozluk
category: "dev"
aliases:
  - "Compiler"
url: "https://trescout.com/dictionary/compiler/"
---

# Compiler 

> [!NOTE] Tanım
> İnsanların yazdığı kodları, bilgisayarın doğrudan anlayıp çalıştırabileceği makine diline çeviren programdır.

## İngilizce Açıklama
It is a program that translates the codes written by humans into machine language that the computer can directly understand and execute.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/compiler/)*
