---
title: "Benchmark"
type: sozluk
category: "ai"
aliases:
  - "Benchmark"
url: "https://trescout.com/dictionary/benchmark/"
---

# Benchmark 

> [!NOTE] Tanım
> Bir yazılımın veya donanımın performansını standart testlerle ölçüp diğerleriyle kıyaslama yöntemidir.

## İngilizce Açıklama
It is a method of measuring the performance of a software or hardware with standard tests and comparing it with others.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/benchmark/)*
