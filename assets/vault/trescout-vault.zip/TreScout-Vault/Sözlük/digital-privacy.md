---
title: "Digital Privacy"
type: sozluk
category: "data"
aliases:
  - "Digital Privacy"
url: "https://trescout.com/dictionary/digital-privacy/"
---

# Digital Privacy 

> [!NOTE] Tanım
> İnternet üzerindeki kişisel verilerinizin kimler tarafından görülebileceğini kontrol etme hakkınızdır.

## İngilizce Açıklama
It is your right to control who can view your personal data on the Internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/digital-privacy/)*
