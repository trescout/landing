---
title: "Autonomous Robotics"
type: sozluk
category: "ai"
aliases:
  - "Autonomous Robotics"
url: "https://trescout.com/dictionary/autonomous-robotics/"
---

# Autonomous Robotics 

> [!NOTE] Tanım
> İnsan müdahalesi olmadan, çevresini algılayıp kendi kararlarını vererek hareket edebilen makinelerdir.

## İngilizce Açıklama
They are machines that can act by sensing their environment and making their own decisions, without human intervention.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/autonomous-robotics/)*
