---
title: "End-to-End Privacy"
type: sozluk
category: "dev"
aliases:
  - "End-to-End Privacy"
url: "https://trescout.com/dictionary/end-to-end-privacy/"
---

# End-to-End Privacy 

> [!NOTE] Tanım
> Verilerin sadece gönderen ve alıcı tarafından okunabildiği, aradaki kimsenin erişemediği bir güvenlik yöntemidir.

## İngilizce Açıklama
It is a security method in which data can only be read by the sender and receiver, and no one in between can access it.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/end-to-end-privacy/)*
