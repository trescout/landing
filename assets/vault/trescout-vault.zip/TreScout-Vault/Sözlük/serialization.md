---
title: "Serialization"
type: sozluk
category: "dev"
aliases:
  - "Serialization"
url: "https://trescout.com/dictionary/serialization/"
---

# Serialization 

> [!NOTE] Tanım
> Karmaşık veri yapılarını, depolanabilir veya iletilebilir düz bir metin veya bayt dizisine dönüştürme işlemidir.

## İngilizce Açıklama
It is the process of converting complex data structures into a plain text or byte array that can be stored or transmitted.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/serialization/)*
