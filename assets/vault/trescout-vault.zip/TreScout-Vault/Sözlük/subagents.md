---
title: "Subagents"
type: sozluk
category: "ai"
aliases:
  - "Subagents"
url: "https://trescout.com/dictionary/subagents/"
---

# Subagents 

> [!NOTE] Tanım
> Ana bir yapay zekâ sisteminin yönetimi altında, daha küçük ve özel görevleri yerine getiren yardımcı birimlerdir.

## İngilizce Açıklama
They are auxiliary units that perform smaller and specific tasks under the management of a main artificial intelligence system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/subagents/)*
