---
title: "Gamification"
type: sozluk
category: "dev"
aliases:
  - "Gamification"
url: "https://trescout.com/dictionary/gamification/"
---

# Gamification 

> [!NOTE] Tanım
> Oyun dışı alanlarda kullanıcıyı motive etmek için oyun mekaniklerinin kullanılmasıdır.

## İngilizce Açıklama
It is the use of game mechanics to motivate the user in non-game areas.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/gamification/)*
