---
title: "Voice Synthesis"
type: sozluk
category: "ai"
aliases:
  - "Voice Synthesis"
url: "https://trescout.com/dictionary/voice-synthesis/"
---

# Voice Synthesis 

> [!NOTE] Tanım
> Yazılı metinlerin bilgisayar tarafından doğal ve akıcı bir insan sesiyle seslendirilmesi teknolojisidir.

## İngilizce Açıklama
It is the technology of voicing written texts with a natural and fluent human voice by a computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/voice-synthesis/)*
