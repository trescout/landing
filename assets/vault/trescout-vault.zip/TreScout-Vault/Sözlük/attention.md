---
title: "Attention"
type: sozluk
category: "ai"
aliases:
  - "Attention"
url: "https://trescout.com/dictionary/attention/"
---

# Attention 

> [!NOTE] Tanım
> Yapay zekânın bir metin veya veri içindeki en önemli parçalara odaklanmasını sağlayan mekanizma.

## İngilizce Açıklama
A mechanism that allows artificial intelligence to focus on the most important pieces within a text or data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/attention/)*
