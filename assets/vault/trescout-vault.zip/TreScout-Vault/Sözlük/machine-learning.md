---
title: "Machine Learning"
type: sozluk
category: "ai"
aliases:
  - "Machine Learning"
url: "https://trescout.com/dictionary/machine-learning/"
---

# Machine Learning 

> [!NOTE] Tanım
> Bilgisayarların verilerden ders çıkararak kendi kendine öğrenmesini sağlayan teknolojidir.

## İngilizce Açıklama
It is technology that enables computers to learn on their own by learning from data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/machine-learning/)*
