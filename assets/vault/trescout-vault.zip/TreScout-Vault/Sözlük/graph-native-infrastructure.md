---
title: "Graph-native Infrastructure"
type: sozluk
category: "data"
aliases:
  - "Graph-native Infrastructure"
url: "https://trescout.com/dictionary/graph-native-infrastructure/"
---

# Graph-native Infrastructure 

> [!NOTE] Tanım
> Veriler arasındaki doğrudan bağlantıları temel alarak tasarlanmış özel bir veri depolama yapısıdır.

## İngilizce Açıklama
It is a special data storage structure designed based on direct connections between data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/graph-native-infrastructure/)*
