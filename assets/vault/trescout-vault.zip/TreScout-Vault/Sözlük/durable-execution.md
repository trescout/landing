---
title: "Durable Execution"
type: sozluk
category: "dev"
aliases:
  - "Durable Execution"
url: "https://trescout.com/dictionary/durable-execution/"
---

# Durable Execution 

> [!NOTE] Tanım
> Bir işlemin, hata veya kesinti olsa bile kaldığı yerden güvenle devam etmesini sağlayan sistemdir.

## İngilizce Açıklama
It is a system that allows a process to continue safely where it left off, even if there is an error or interruption.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/durable-execution/)*
