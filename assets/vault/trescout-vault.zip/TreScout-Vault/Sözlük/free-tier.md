---
title: "Free Tier"
type: sozluk
category: "dev"
aliases:
  - "Free Tier"
url: "https://trescout.com/dictionary/free-tier/"
---

# Free Tier 

> [!NOTE] Tanım
> Bir hizmetin sınırlı özelliklerle ücretsiz olarak sunulan başlangıç seviyesidir.

## İngilizce Açıklama
It is the entry level of a service offered for free with limited features.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/free-tier/)*
