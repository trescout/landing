---
title: "QA"
type: sozluk
category: "dev"
aliases:
  - "QA"
  - "Quality Assurance"
url: "https://trescout.com/dictionary/qa/"
---

# QA (Quality Assurance)

> [!NOTE] Tanım
> Bir yazılımın kullanıcıya ulaşmadan önce belirlenen standartlara uygun, hatasız ve kaliteli olduğundan emin olma sürecidir.

## İngilizce Açıklama
It is the process of making sure that a software meets the specified standards, is error-free and of high quality before it reaches the user.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/qa/)*
