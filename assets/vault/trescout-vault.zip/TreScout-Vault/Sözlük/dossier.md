---
title: "Dossier"
type: sozluk
category: "data"
aliases:
  - "Dossier"
url: "https://trescout.com/dictionary/dossier/"
---

# Dossier 

> [!NOTE] Tanım
> Belirli bir konu veya kişi hakkındaki tüm belgelerin ve bilgilerin bir araya getirildiği düzenli bir dosya sistemidir.

## İngilizce Açıklama
It is an organized file system in which all documents and information about a particular subject or person are brought together.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dossier/)*
