---
title: "Context Window"
type: sozluk
category: "ai"
aliases:
  - "Context Window"
url: "https://trescout.com/dictionary/context-window/"
---

# Context Window 

> [!NOTE] Tanım
> Yapay zekanın tek seferde hatırlayabildiği ve işleyebildiği bilgi kapasitesidir.

## İngilizce Açıklama
It is the information capacity that artificial intelligence can remember and process at once.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/context-window/)*
