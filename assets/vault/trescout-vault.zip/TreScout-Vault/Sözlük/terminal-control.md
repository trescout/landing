---
title: "Terminal Control"
type: sozluk
category: "dev"
aliases:
  - "Terminal Control"
url: "https://trescout.com/dictionary/terminal-control/"
---

# Terminal Control 

> [!NOTE] Tanım
> Bilgisayara grafik arayüz (fare ve pencere) kullanmadan, doğrudan komut satırı üzerinden talimat verme sürecidir.

## İngilizce Açıklama
It is the process of giving instructions to the computer directly via the command line, without using a graphical interface (mouse and windows).

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/terminal-control/)*
