---
title: "Local-first"
type: sozluk
category: "dev"
aliases:
  - "Local-first"
url: "https://trescout.com/dictionary/local-first/"
---

# Local-first 

> [!NOTE] Tanım
> İnternet bağlantısına bağımlı kalmadan, verilerin cihazda tutulmasını ve işlenmesini esas alan yazılım yaklaşımıdır.

## İngilizce Açıklama
It is a software approach based on keeping and processing data on the device without being dependent on an internet connection.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/local-first/)*
