---
title: "DNS Tunneling"
type: sozluk
category: "dev"
aliases:
  - "DNS Tunneling"
url: "https://trescout.com/dictionary/dns-tunneling/"
---

# DNS Tunneling 

> [!NOTE] Tanım
> İnternet trafiğini normalde adres bulmak için kullanılan sistem üzerinden gizlice geçirme yöntemidir.

## İngilizce Açıklama
It is a method of secretly passing Internet traffic through the system normally used to find addresses.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dns-tunneling/)*
