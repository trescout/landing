---
title: "Home Automation"
type: sozluk
category: "ai"
aliases:
  - "Home Automation"
url: "https://trescout.com/dictionary/home-automation/"
---

# Home Automation 

> [!NOTE] Tanım
> Evinizdeki cihazların yapay zekâ veya internet üzerinden otomatik olarak kontrol edilmesidir.

## İngilizce Açıklama
It is the automatic control of the devices in your home via artificial intelligence or the internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/home-automation/)*
