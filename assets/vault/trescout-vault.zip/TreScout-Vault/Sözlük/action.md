---
title: "Action"
type: sozluk
category: "ai"
aliases:
  - "Action"
url: "https://trescout.com/dictionary/action/"
---

# Action 

> [!NOTE] Tanım
> Bir yapay zekanın veya yazılımın, kendisine verilen komut üzerine dış dünyada veya sistem içinde yaptığı somut işlemdir.

## İngilizce Açıklama
It is the concrete action that an artificial intelligence or software performs in the outside world or within the system upon the command given to it.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/action/)*
