---
title: "Operating System for Robotics"
type: sozluk
category: "dev"
aliases:
  - "Operating System for Robotics"
  - "ROS"
url: "https://trescout.com/dictionary/operating-system-for-robotics/"
---

# Operating System for Robotics (ROS)

> [!NOTE] Tanım
> Robotların hareketlerini, sensörlerini ve karmaşık parçalarını yöneten özel bir yazılım altyapısıdır.

## İngilizce Açıklama
It is a special software infrastructure that manages the movements, sensors and complex parts of robots.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/operating-system-for-robotics/)*
