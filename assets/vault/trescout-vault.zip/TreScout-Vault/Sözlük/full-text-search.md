---
title: "Full Text Search"
type: sozluk
category: "data"
aliases:
  - "Full Text Search"
url: "https://trescout.com/dictionary/full-text-search/"
---

# Full Text Search 

> [!NOTE] Tanım
> Bir belgedeki veya veritabanındaki sadece başlıkları değil, tüm metin içeriğini tarayarak yapılan detaylı arama yöntemidir.

## İngilizce Açıklama
It is a detailed search method performed by scanning the entire text content of a document or database, not just the titles.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/full-text-search/)*
