---
title: "Tutoring"
type: sozluk
category: "ai"
aliases:
  - "Tutoring"
url: "https://trescout.com/dictionary/tutoring/"
---

# Tutoring 

> [!NOTE] Tanım
> Yapay zekânın bir öğrenciye özel bir öğretmen gibi konuları anlatması ve rehberlik etmesidir.

## İngilizce Açıklama
Artificial intelligence explains and guides a student like a private teacher.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/tutoring/)*
