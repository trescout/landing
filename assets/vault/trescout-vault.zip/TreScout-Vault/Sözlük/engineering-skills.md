---
title: "Engineering Skills"
type: sozluk
category: "dev"
aliases:
  - "Engineering Skills"
url: "https://trescout.com/dictionary/engineering-skills/"
---

# Engineering Skills 

> [!NOTE] Tanım
> Karmaşık problemleri çözmek için mantık ve matematik kullanarak sistemler tasarlama ve inşa etme yeteneğidir.

## İngilizce Açıklama
It is the ability to design and build systems using logic and mathematics to solve complex problems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/engineering-skills/)*
