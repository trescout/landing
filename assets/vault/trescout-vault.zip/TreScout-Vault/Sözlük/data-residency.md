---
title: "Data Residency"
type: sozluk
category: "data"
aliases:
  - "Data Residency"
url: "https://trescout.com/dictionary/data-residency/"
---

# Data Residency 

> [!NOTE] Tanım
> Verilerin yasal nedenlerle belirli bir coğrafi bölge veya ülke sınırları içinde tutulması zorunluluğudur.

## İngilizce Açıklama
It is the obligation to keep data within the borders of a certain geographical region or country for legal reasons.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/data-residency/)*
