---
title: "Compound Engineering"
type: sozluk
category: "dev"
aliases:
  - "Compound Engineering"
url: "https://trescout.com/dictionary/compound-engineering/"
---

# Compound Engineering 

> [!NOTE] Tanım
> Her mühendislik adımının bir sonrakini kolaylaştıracak şekilde biriktiği, yapay zekâ destekli bir çalışma yaklaşımıdır.

## İngilizce Açıklama
It is an AI-supported approach to work where each engineering step accumulates to facilitate the next.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/compound-engineering/)*
