---
title: "Multimodal"
type: sozluk
category: "ai"
aliases:
  - "Multimodal"
url: "https://trescout.com/dictionary/multimodal/"
---

# Multimodal 

> [!NOTE] Tanım
> Metin, ses, görsel ve video gibi farklı veri türlerini aynı anda işleyebilen yapay zekâ yeteneğidir.

## İngilizce Açıklama
It is an artificial intelligence ability that can simultaneously process different types of data such as text, audio, visual and video.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/multimodal/)*
