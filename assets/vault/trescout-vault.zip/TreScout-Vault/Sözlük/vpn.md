---
title: "VPN"
type: sozluk
category: "dev"
aliases:
  - "VPN"
  - "Virtual Private Network"
url: "https://trescout.com/dictionary/vpn/"
---

# VPN (Virtual Private Network)

> [!NOTE] Tanım
> İnternet üzerindeki verilerinizi şifreleyerek kimliğinizi gizleyen ve güvenli bağlantı sağlayan araçtır.

## İngilizce Açıklama
It is a tool that hides your identity and provides a secure connection by encrypting your data on the internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/vpn/)*
