---
title: "Dial Keys"
type: sozluk
category: "dev"
aliases:
  - "Dial Keys"
url: "https://trescout.com/dictionary/dial-keys/"
---

# Dial Keys 

> [!NOTE] Tanım
> Eski telefonlarda numara çevirmek için kullanılan, döndürülerek çalışan mekanik tuş takımıdır.

## İngilizce Açıklama
It is a rotating mechanical keypad used to dial numbers on old phones.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dial-keys/)*
