---
title: "Bash Script"
type: sozluk
category: "dev"
aliases:
  - "Bash Script"
url: "https://trescout.com/dictionary/bash-script/"
---

# Bash Script 

> [!NOTE] Tanım
> Bilgisayarda yapılması gereken çok adımlı işlemleri tek bir dosyada toplayarak otomatikleştiren bir komut dizisidir.

## İngilizce Açıklama
It is a command sequence that automates multi-step operations that need to be done on the computer by collecting them in a single file.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bash-script/)*
