---
title: "Video Editor"
type: sozluk
category: "dev"
aliases:
  - "Video Editor"
url: "https://trescout.com/dictionary/video-editor/"
---

# Video Editor 

> [!NOTE] Tanım
> Görüntü ve ses dosyalarını düzenleyerek bir video haline getiren yazılımlardır.

## İngilizce Açıklama
They are software that edits image and audio files and turns them into a video.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/video-editor/)*
