---
title: "Vibe Coding"
type: sozluk
category: "ai"
aliases:
  - "Vibe Coding"
url: "https://trescout.com/dictionary/vibe-coding/"
---

# Vibe Coding 

> [!NOTE] Tanım
> Teknik ayrıntılara girmeden, sadece ne istediğinizi tarif ederek yapay zekâ ile kod yazma yaklaşımıdır.

## İngilizce Açıklama
It is an approach to writing code with artificial intelligence by simply describing what you want, without going into technical details.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/vibe-coding/)*
