---
title: "Open Weights"
type: sozluk
category: "ai"
aliases:
  - "Open Weights"
url: "https://trescout.com/dictionary/open-weights/"
---

# Open Weights 

> [!NOTE] Tanım
> Yapay zekâ modelinin eğitilmiş iç parametrelerinin herkesle paylaşılmasıdır.

## İngilizce Açıklama
It is the sharing of the trained internal parameters of the artificial intelligence model with everyone.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/open-weights/)*
