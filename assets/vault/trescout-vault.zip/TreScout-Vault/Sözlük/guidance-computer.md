---
title: "Guidance Computer"
type: sozluk
category: "ai"
aliases:
  - "Guidance Computer"
url: "https://trescout.com/dictionary/guidance-computer/"
---

# Guidance Computer 

> [!NOTE] Tanım
> Bir aracın veya sistemin rotasını hesaplayan, otonom olarak hedefe ulaşmasını sağlayan yönlendirme beynidir.

## İngilizce Açıklama
It is the guidance brain that calculates the route of a vehicle or system and enables it to reach the target autonomously.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/guidance-computer/)*
