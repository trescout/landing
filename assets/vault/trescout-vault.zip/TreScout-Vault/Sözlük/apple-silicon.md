---
title: "Apple Silicon"
type: sozluk
category: "dev"
aliases:
  - "Apple Silicon"
url: "https://trescout.com/dictionary/apple-silicon/"
---

# Apple Silicon 

> [!NOTE] Tanım
> Apple tarafından bilgisayarlar için özel olarak tasarlanan, yüksek performans ve düşük enerji tüketen işlemci mimarisidir.

## İngilizce Açıklama
It is a high-performance and low-energy processor architecture designed specifically for computers by Apple.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/apple-silicon/)*
