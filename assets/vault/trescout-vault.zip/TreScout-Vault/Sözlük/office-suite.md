---
title: "Office Suite"
type: sozluk
category: "dev"
aliases:
  - "Office Suite"
url: "https://trescout.com/dictionary/office-suite/"
---

# Office Suite 

> [!NOTE] Tanım
> Günlük ofis işlerini dijital ortamda yapmak için bir araya getirilmiş yazılım paketidir.

## İngilizce Açıklama
It is a software package put together to perform daily office work in a digital environment.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/office-suite/)*
