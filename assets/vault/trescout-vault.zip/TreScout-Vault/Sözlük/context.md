---
title: "Context"
type: sozluk
category: "ai"
aliases:
  - "Context"
url: "https://trescout.com/dictionary/context/"
---

# Context 

> [!NOTE] Tanım
> Yapay zekânın bir konuyu doğru anlaması için ihtiyaç duyduğu geçmiş bilgiler ve mevcut durumun bütünüdür.

## İngilizce Açıklama
It is the whole of the past information and current situation that artificial intelligence needs to understand a subject correctly.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/context/)*
