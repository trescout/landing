---
title: "TDD"
type: sozluk
category: "dev"
aliases:
  - "TDD"
  - "Test-Driven Development"
url: "https://trescout.com/dictionary/tdd/"
---

# TDD (Test-Driven Development)

> [!NOTE] Tanım
> Önce yazılacak kodun testini hazırlayıp, ardından bu testi geçecek kadar kod yazmayı esas alan geliştirme yöntemidir.

## İngilizce Açıklama
It is a development method based on first preparing the test of the code to be written and then writing enough code to pass this test.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/tdd/)*
