---
title: "Web UI"
type: sozluk
category: "dev"
aliases:
  - "Web UI"
  - "Web User Interface"
url: "https://trescout.com/dictionary/web-ui/"
---

# Web UI (Web User Interface)

> [!NOTE] Tanım
> Bir yazılımı bilgisayarınıza kurmak yerine internet tarayıcısı üzerinden kullanmanıza olanak tanıyan görsel arayüz.

## İngilizce Açıklama
A visual interface that allows you to use a software via an internet browser instead of installing it on your computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/web-ui/)*
