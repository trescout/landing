---
title: "Design System"
type: sozluk
category: "dev"
aliases:
  - "Design System"
url: "https://trescout.com/dictionary/design-system/"
---

# Design System 

> [!NOTE] Tanım
> Uygulama geliştirirken kullanılan tasarım standartları ve bileşenler bütünüdür.

## İngilizce Açıklama
It is the set of design standards and components used when developing applications.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/design-system/)*
