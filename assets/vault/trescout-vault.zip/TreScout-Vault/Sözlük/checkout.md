---
title: "Checkout"
type: sozluk
category: "dev"
aliases:
  - "Checkout"
url: "https://trescout.com/dictionary/checkout/"
---

# Checkout 

> [!NOTE] Tanım
> Bir alışveriş sürecinin sonunda ödeme ve onay işlemlerinin gerçekleştirildiği son aşamadır.

## İngilizce Açıklama
It is the final stage where payment and approval transactions are carried out at the end of a shopping process.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/checkout/)*
