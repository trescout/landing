---
title: "Grounded Summary"
type: sozluk
category: "ai"
aliases:
  - "Grounded Summary"
url: "https://trescout.com/dictionary/grounded-summary/"
---

# Grounded Summary 

> [!NOTE] Tanım
> Yapay zekanın sadece sağlanan kaynak belgelere sadık kalarak oluşturduğu, uydurma içermeyen özetleme yöntemidir.

## İngilizce Açıklama
It is a summary method that does not involve fabrication and is created by artificial intelligence by adhering only to the source documents provided.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/grounded-summary/)*
