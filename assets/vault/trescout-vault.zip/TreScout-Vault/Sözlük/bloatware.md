---
title: "Bloatware"
type: sozluk
category: "dev"
aliases:
  - "Bloatware"
url: "https://trescout.com/dictionary/bloatware/"
---

# Bloatware 

> [!NOTE] Tanım
> Bilgisayar veya telefona önceden yüklenmiş, genellikle gereksiz yer kaplayan ve sistemi yavaşlatan yazılımlardır.

## İngilizce Açıklama
They are software pre-installed on the computer or phone, which usually take up unnecessary space and slow down the system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bloatware/)*
