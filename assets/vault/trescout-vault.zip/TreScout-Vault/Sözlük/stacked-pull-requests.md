---
title: "Stacked Pull Requests"
type: sozluk
category: "dev"
aliases:
  - "Stacked Pull Requests"
url: "https://trescout.com/dictionary/stacked-pull-requests/"
---

# Stacked Pull Requests 

> [!NOTE] Tanım
> Büyük yazılım değişikliklerini, birbirine bağlı küçük ve yönetilebilir parçalar halinde sırayla sisteme ekleme yöntemidir.

## İngilizce Açıklama
It is a method of introducing major software changes into the system sequentially in small, manageable pieces that are interconnected.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/stacked-pull-requests/)*
