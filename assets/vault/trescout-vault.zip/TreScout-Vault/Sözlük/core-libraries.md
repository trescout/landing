---
title: "Core Libraries"
type: sozluk
category: "dev"
aliases:
  - "Core Libraries"
url: "https://trescout.com/dictionary/core-libraries/"
---

# Core Libraries 

> [!NOTE] Tanım
> Bir yazılımın temel işlevlerini yerine getirmesi için ihtiyaç duyduğu standart kod paketleridir.

## İngilizce Açıklama
They are standard code packages that a software needs to perform its basic functions.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/core-libraries/)*
