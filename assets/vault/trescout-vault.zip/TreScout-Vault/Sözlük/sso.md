---
title: "SSO"
type: sozluk
category: "dev"
aliases:
  - "SSO"
  - "Single Sign-On"
url: "https://trescout.com/dictionary/sso/"
---

# SSO (Single Sign-On)

> [!NOTE] Tanım
> Tek bir kullanıcı adı ve şifre ile birçok farklı uygulamaya aynı anda giriş yapmanızı sağlayan sistemdir.

## İngilizce Açıklama
It is a system that allows you to log in to many different applications at the same time with a single username and password.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/sso/)*
