---
title: "Rust"
type: sozluk
category: "dev"
aliases:
  - "Rust"
url: "https://trescout.com/dictionary/rust/"
---

# Rust 

> [!NOTE] Tanım
> Hafıza güvenliğini ön planda tutan, yüksek performanslı bir sistem programlama dilidir.

## İngilizce Açıklama
It is a high-performance system programming language that prioritizes memory security.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/rust/)*
