---
title: "Whisper"
type: sozluk
category: "ai"
aliases:
  - "Whisper"
url: "https://trescout.com/dictionary/whisper/"
---

# Whisper 

> [!NOTE] Tanım
> Konuşulan dili yüksek doğrulukla metne dönüştüren, yapay zekâ tabanlı bir ses tanıma teknolojisidir.

## İngilizce Açıklama
It is an artificial intelligence-based voice recognition technology that converts spoken language into text with high accuracy.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/whisper/)*
