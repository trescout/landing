---
title: "Memory"
type: sozluk
category: "ai"
aliases:
  - "Memory"
url: "https://trescout.com/dictionary/memory/"
---

# Memory 

> [!NOTE] Tanım
> Yapay zekânın geçmiş etkileşimleri saklayarak, gelecekteki cevaplarını bu bilgilere göre kişiselleştirme yeteneğidir.

## İngilizce Açıklama
It is the ability of artificial intelligence to store past interactions and personalize its future responses based on this information.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/memory/)*
