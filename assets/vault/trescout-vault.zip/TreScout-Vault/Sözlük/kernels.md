---
title: "Kernels"
type: sozluk
category: "dev"
aliases:
  - "Kernels"
url: "https://trescout.com/dictionary/kernels/"
---

# Kernels 

> [!NOTE] Tanım
> Bilgisayarın donanımı ile yazılımları arasındaki iletişimi yöneten işletim sisteminin en temel parçası.

## İngilizce Açıklama
The most basic part of the operating system that manages the communication between the computer's hardware and software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/kernels/)*
