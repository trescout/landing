---
title: "Sandbox"
type: sozluk
category: "dev"
aliases:
  - "Sandbox"
url: "https://trescout.com/dictionary/sandbox/"
---

# Sandbox 

> [!NOTE] Tanım
> Yeni yazılımların veya kodların ana sisteme zarar vermeden güvenle test edilebildiği yalıtılmış çalışma alanıdır.

## İngilizce Açıklama
It is an isolated work area where new software or codes can be tested safely without damaging the main system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/sandbox/)*
