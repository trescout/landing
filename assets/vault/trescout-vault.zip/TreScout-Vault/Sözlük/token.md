---
title: "Token"
type: sozluk
category: "ai"
aliases:
  - "Token"
url: "https://trescout.com/dictionary/token/"
---

# Token 

> [!NOTE] Tanım
> Yapay zekanın metinleri işlemek için kullandığı en küçük anlam birimidir.

## İngilizce Açıklama
It is the smallest unit of meaning that artificial intelligence uses to process texts.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/token/)*
