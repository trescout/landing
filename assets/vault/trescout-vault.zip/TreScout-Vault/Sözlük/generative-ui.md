---
title: "Generative UI"
type: sozluk
category: "ai"
aliases:
  - "Generative UI"
url: "https://trescout.com/dictionary/generative-ui/"
---

# Generative UI 

> [!NOTE] Tanım
> Kullanıcının o anki ihtiyacına göre yapay zekâ tarafından anlık olarak oluşturulan ekran tasarımıdır.

## İngilizce Açıklama
It is a screen design created instantly by artificial intelligence according to the user's current needs.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/generative-ui/)*
