---
title: "Physical AI"
type: sozluk
category: "ai"
aliases:
  - "Physical AI"
url: "https://trescout.com/dictionary/physical-ai/"
---

# Physical AI 

> [!NOTE] Tanım
> Robotlar gibi fiziksel dünyadaki nesneleri kontrol edebilen ve çevreyle etkileşime giren yapay zekâ sistemleri.

## İngilizce Açıklama
Artificial intelligence systems that can control objects in the physical world, such as robots, and interact with the environment.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/physical-ai/)*
