---
title: "Security Scanner"
type: sozluk
category: "dev"
aliases:
  - "Security Scanner"
url: "https://trescout.com/dictionary/security-scanner/"
---

# Security Scanner 

> [!NOTE] Tanım
> Yazılım veya ağ sistemlerindeki güvenlik açıklarını otomatik olarak tespit eden bir araçtır.

## İngilizce Açıklama
It is a tool that automatically detects vulnerabilities in software or network systems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/security-scanner/)*
