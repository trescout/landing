---
title: "CRISPR"
type: sozluk
category: "ai"
aliases:
  - "CRISPR"
  - "Clustered Regularly Interspaced Short Palindromic Repeats"
url: "https://trescout.com/dictionary/crispr/"
---

# CRISPR (Clustered Regularly Interspaced Short Palindromic Repeats)

> [!NOTE] Tanım
> Canlıların genetik kodlarını bir kelime işlemciyle metin düzenler gibi değiştirmeye yarayan hassas bir biyoteknoloji aracıdır.

## İngilizce Açıklama
It is a sensitive biotechnology tool that helps modify the genetic codes of living things, just like editing text with a word processor.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/crispr/)*
