---
title: "RBAC"
type: sozluk
category: "dev"
aliases:
  - "RBAC"
  - "Role-Based Access Control"
url: "https://trescout.com/dictionary/rbac/"
---

# RBAC (Role-Based Access Control)

> [!NOTE] Tanım
> Kullanıcılara sistem içindeki görevlerine göre yetki verme ve erişim sınırlandırma yöntemidir.

## İngilizce Açıklama
It is a method of authorizing and limiting access to users according to their roles within the system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/rbac/)*
