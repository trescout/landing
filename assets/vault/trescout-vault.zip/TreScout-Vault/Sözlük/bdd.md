---
title: "BDD"
type: sozluk
category: "dev"
aliases:
  - "BDD"
  - "Behavior-Driven Development"
url: "https://trescout.com/dictionary/bdd/"
---

# BDD (Behavior-Driven Development)

> [!NOTE] Tanım
> Yazılımın nasıl davranması gerektiğini herkesin anlayabileceği basit cümlelerle tanımlayarak geliştirme süreci.

## İngilizce Açıklama
The development process of defining how software should behave in simple sentences that everyone can understand.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bdd/)*
