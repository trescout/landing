---
title: "Multi-tenancy"
type: sozluk
category: "dev"
aliases:
  - "Multi-tenancy"
url: "https://trescout.com/dictionary/multi-tenancy/"
---

# Multi-tenancy 

> [!NOTE] Tanım
> Tek bir yazılımın, aynı anda birçok farklı kullanıcıya veya şirkete birbirinden bağımsız hizmet vermesidir.

## İngilizce Açıklama
It is the ability of a single software to provide independent services to many different users or companies at the same time.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/multi-tenancy/)*
