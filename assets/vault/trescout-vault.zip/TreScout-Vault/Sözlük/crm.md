---
title: "CRM"
type: sozluk
category: "data"
aliases:
  - "CRM"
  - "Customer Relationship Management"
url: "https://trescout.com/dictionary/crm/"
---

# CRM (Customer Relationship Management)

> [!NOTE] Tanım
> Şirketlerin müşteri bilgilerini, geçmiş etkileşimlerini ve satış süreçlerini tek bir merkezden yönetmesini sağlayan dijital sistemdir.

## İngilizce Açıklama
It is a digital system that allows companies to manage customer information, past interactions and sales processes from a single center.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/crm/)*
