---
title: "Hermes Agent"
type: sozluk
category: "ai"
aliases:
  - "Hermes Agent"
url: "https://trescout.com/dictionary/hermes-agent/"
---

# Hermes Agent 

> [!NOTE] Tanım
> Kullanıcı adına otonom kararlar alabilen ve belirli görevleri uçtan uca tamamlayan özel bir yapay zekâ birimidir.

## İngilizce Açıklama
It is a special artificial intelligence unit that can make autonomous decisions on behalf of the user and complete certain tasks end-to-end.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/hermes-agent/)*
