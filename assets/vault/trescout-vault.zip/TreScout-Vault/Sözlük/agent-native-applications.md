---
title: "Agent-native Applications"
type: sozluk
category: "ai"
aliases:
  - "Agent-native Applications"
url: "https://trescout.com/dictionary/agent-native-applications/"
---

# Agent-native Applications 

> [!NOTE] Tanım
> Yapay zekâ ajanlarının karar alıp işlemleri yürütmesi için özel olarak tasarlanmış uygulamalardır.

## İngilizce Açıklama
They are applications specifically designed for artificial intelligence agents to make decisions and carry out transactions.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agent-native-applications/)*
