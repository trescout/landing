---
title: "Static Typing"
type: sozluk
category: "dev"
aliases:
  - "Static Typing"
url: "https://trescout.com/dictionary/static-typing/"
---

# Static Typing 

> [!NOTE] Tanım
> Programdaki verilerin türlerinin, kod çalıştırılmadan önce yazım aşamasında kesin olarak belirlenmesi kuralıdır.

## İngilizce Açıklama
It is a rule that the types of data in the program are precisely determined at the writing stage before the code is run.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/static-typing/)*
