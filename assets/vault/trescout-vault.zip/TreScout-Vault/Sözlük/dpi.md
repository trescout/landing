---
title: "DPI"
type: sozluk
category: "dev"
aliases:
  - "DPI"
  - "Dots Per Inch"
url: "https://trescout.com/dictionary/dpi/"
---

# DPI (Dots Per Inch)

> [!NOTE] Tanım
> Bir ekranın veya yazıcının görüntü kalitesini belirleyen, inç başına düşen nokta sayısıdır.

## İngilizce Açıklama
The number of dots per inch determines the image quality of a display or printer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dpi/)*
