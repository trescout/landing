---
title: "Generative AI"
type: sozluk
category: "ai"
aliases:
  - "Generative AI"
url: "https://trescout.com/dictionary/generative-ai/"
---

# Generative AI 

> [!NOTE] Tanım
> Yeni içerik, metin, görsel veya ses üretebilen yapay zekâ teknolojilerinin genel adıdır.

## İngilizce Açıklama
It is the general name of artificial intelligence technologies that can produce new content, text, visuals or audio.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/generative-ai/)*
