---
title: "Runtime"
type: sozluk
category: "dev"
aliases:
  - "Runtime"
url: "https://trescout.com/dictionary/runtime/"
---

# Runtime 

> [!NOTE] Tanım
> Bir yazılımın bilgisayarda çalıştırıldığı an ve bu süreçte ihtiyaç duyduğu ortamdır.

## İngilizce Açıklama
It is the moment when a software is run on the computer and the environment it needs in this process.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/runtime/)*
