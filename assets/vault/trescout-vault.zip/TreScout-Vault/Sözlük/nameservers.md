---
title: "Nameservers"
type: sozluk
category: "dev"
aliases:
  - "Nameservers"
url: "https://trescout.com/dictionary/nameservers/"
---

# Nameservers 

> [!NOTE] Tanım
> İnsanların kullandığı web sitesi isimlerini, bilgisayarların anladığı sayısal adreslere dönüştüren bir telefon rehberidir.

## İngilizce Açıklama
It is a phone book that converts website names used by people into numerical addresses that computers understand.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/nameservers/)*
