---
title: "AI Companion"
type: sozluk
category: "ai"
aliases:
  - "AI Companion"
url: "https://trescout.com/dictionary/ai-companion/"
---

# AI Companion 

> [!NOTE] Tanım
> Kullanıcıyla etkileşim kurarak arkadaşlık eden veya günlük işlerde yardımcı olan yapay zekâ uygulamasıdır.

## İngilizce Açıklama
It is an artificial intelligence application that interacts with the user, befriends him or helps him with daily tasks.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/ai-companion/)*
