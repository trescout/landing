---
title: "User Experience"
type: sozluk
category: "dev"
aliases:
  - "User Experience"
  - "UX"
url: "https://trescout.com/dictionary/user-experience/"
---

# User Experience (UX)

> [!NOTE] Tanım
> Bir ürünü kullanırken yaşadığınız genel kolaylık, hız ve memnuniyet duygusudur.

## İngilizce Açıklama
It is the overall feeling of ease, speed and satisfaction you experience when using a product.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/user-experience/)*
