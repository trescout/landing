---
title: "Deepfake"
type: sozluk
category: "ai"
aliases:
  - "Deepfake"
url: "https://trescout.com/dictionary/deepfake/"
---

# Deepfake 

> [!NOTE] Tanım
> Yapay zekâ ile bir kişinin sesini veya görüntüsünü başka birine gerçeğinden ayırt edilemeyecek şekilde uyarlama teknolojisi.

## İngilizce Açıklama
The technology of adapting one person's voice or image to another person in a way that is indistinguishable from the real thing, using artificial intelligence.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/deepfake/)*
