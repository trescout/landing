---
title: "Deep Learning"
type: sozluk
category: "ai"
aliases:
  - "Deep Learning"
url: "https://trescout.com/dictionary/deep-learning/"
---

# Deep Learning 

> [!NOTE] Tanım
> Yapay sinir ağlarını kullanarak bilgisayarların büyük verilerden kendi kendine öğrenmesini sağlayan bir makine öğrenmesi yöntemidir.

## İngilizce Açıklama
It is a machine learning method that allows computers to learn on their own from big data using artificial neural networks.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/deep-learning/)*
