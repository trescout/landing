---
title: "Gateway"
type: sozluk
category: "dev"
aliases:
  - "Gateway"
url: "https://trescout.com/dictionary/gateway/"
---

# Gateway 

> [!NOTE] Tanım
> Farklı ağlar arasında veri trafiğini yöneten ve geçişi sağlayan bağlantı noktasıdır.

## İngilizce Açıklama
It is the port that manages and transitions data traffic between different networks.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/gateway/)*
