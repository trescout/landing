---
title: "Cloud Computing"
type: sozluk
category: "dev"
aliases:
  - "Cloud Computing"
url: "https://trescout.com/dictionary/cloud-computing/"
---

# Cloud Computing 

> [!NOTE] Tanım
> Bilgi işlem hizmetlerinin internet üzerinden uzaktaki sunucular aracılığıyla sunulmasıdır.

## İngilizce Açıklama
It is the provision of computing services via remote servers over the internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/cloud-computing/)*
