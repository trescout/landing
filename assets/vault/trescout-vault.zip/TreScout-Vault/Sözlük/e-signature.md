---
title: "E-signature"
type: sozluk
category: "dev"
aliases:
  - "E-signature"
  - "Electronic Signature"
url: "https://trescout.com/dictionary/e-signature/"
---

# E-signature (Electronic Signature)

> [!NOTE] Tanım
> Dijital belgelerin yasal olarak imzalanmasını ve kimlik doğrulanmasını sağlayan elektronik yöntemdir.

## İngilizce Açıklama
It is an electronic method that allows digital documents to be legally signed and authenticated.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/e-signature/)*
