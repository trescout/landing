---
title: "Markdown"
type: sozluk
category: "dev"
aliases:
  - "Markdown"
url: "https://trescout.com/dictionary/markdown/"
---

# Markdown 

> [!NOTE] Tanım
> Metinleri biçimlendirmek için kullanılan, basit işaretlerle yazı yazmayı sağlayan hafif bir biçimlendirme dili.

## İngilizce Açıklama
A lightweight formatting language used to format text, allowing writing with simple characters.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/markdown/)*
