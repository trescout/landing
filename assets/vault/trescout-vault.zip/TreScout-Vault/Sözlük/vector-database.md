---
title: "Vector Database"
type: sozluk
category: "data"
aliases:
  - "Vector Database"
url: "https://trescout.com/dictionary/vector-database/"
---

# Vector Database 

> [!NOTE] Tanım
> Yapay zekanın verileri anlamlarına göre hızlıca bulabilmesi için saklandığı özel bir veritabanı türüdür.

## İngilizce Açıklama
It is a special type of database where artificial intelligence stores data so that it can quickly find it based on its meaning.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/vector-database/)*
