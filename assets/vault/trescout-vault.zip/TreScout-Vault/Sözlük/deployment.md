---
title: "Deployment"
type: sozluk
category: "dev"
aliases:
  - "Deployment"
url: "https://trescout.com/dictionary/deployment/"
---

# Deployment 

> [!NOTE] Tanım
> Hazırlanan bir yazılımın kullanıcıların erişimine açılması için sunucuya yüklenip çalışır hale getirilmesidir.

## İngilizce Açıklama
It is the process of uploading a prepared software to the server and making it operational so that it can be accessed by users.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/deployment/)*
