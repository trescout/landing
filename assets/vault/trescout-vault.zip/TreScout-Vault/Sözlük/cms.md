---
title: "CMS"
type: sozluk
category: "dev"
aliases:
  - "CMS"
  - "Content Management System"
url: "https://trescout.com/dictionary/cms/"
---

# CMS (Content Management System)

> [!NOTE] Tanım
> Kod yazmayı bilmeden web siteleri üzerinden içerik oluşturmanızı, düzenlemenizi ve yayınlamanızı sağlayan kullanıcı dostu bir yazılımdır.

## İngilizce Açıklama
It is a user-friendly software that allows you to create, edit and publish content on websites without knowing how to code.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/cms/)*
