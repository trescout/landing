---
title: "Computer Science"
type: sozluk
category: "dev"
aliases:
  - "Computer Science"
url: "https://trescout.com/dictionary/computer-science/"
---

# Computer Science 

> [!NOTE] Tanım
> Bilgisayarların çalışma prensiplerini, yazılım geliştirmeyi ve veri işleme yöntemlerini inceleyen bilim dalı.

## İngilizce Açıklama
The branch of science that studies the working principles of computers, software development and data processing methods.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/computer-science/)*
