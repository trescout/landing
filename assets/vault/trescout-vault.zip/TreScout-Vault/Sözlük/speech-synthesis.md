---
title: "Speech Synthesis"
type: sozluk
category: "ai"
aliases:
  - "Speech Synthesis"
url: "https://trescout.com/dictionary/speech-synthesis/"
---

# Speech Synthesis 

> [!NOTE] Tanım
> Yapay zekanın yazılı metinleri insan sesine dönüştürme teknolojisidir.

## İngilizce Açıklama
It is the technology of artificial intelligence to convert written texts into human voices.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/speech-synthesis/)*
