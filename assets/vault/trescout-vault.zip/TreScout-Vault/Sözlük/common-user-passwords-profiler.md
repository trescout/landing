---
title: "Common User Passwords Profiler"
type: sozluk
category: "dev"
aliases:
  - "Common User Passwords Profiler"
  - "CUPS"
url: "https://trescout.com/dictionary/common-user-passwords-profiler/"
---

# Common User Passwords Profiler (CUPS)

> [!NOTE] Tanım
> İnsanların sıkça kullandığı zayıf şifreleri analiz ederek güvenlik açıklarını belirleyen bir araçtır.

## İngilizce Açıklama
It is a tool that identifies security vulnerabilities by analyzing weak passwords that people frequently use.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/common-user-passwords-profiler/)*
