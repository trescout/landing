---
title: "Swarm Intelligence"
type: sozluk
category: "ai"
aliases:
  - "Swarm Intelligence"
url: "https://trescout.com/dictionary/swarm-intelligence/"
---

# Swarm Intelligence 

> [!NOTE] Tanım
> Basit yeteneklere sahip çok sayıda birimin bir araya gelerek tek bir akıllı sistem gibi davranmasıdır.

## İngilizce Açıklama
It is the coming together of many units with simple capabilities and acting as a single intelligent system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/swarm-intelligence/)*
