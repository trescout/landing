---
title: "API"
type: sozluk
category: "dev"
aliases:
  - "API"
  - "Application Programming Interface"
url: "https://trescout.com/dictionary/api/"
---

# API (Application Programming Interface)

> [!NOTE] Tanım
> İki farklı yazılımın birbirleriyle konuşmasını sağlayan dijital köprüdür.

## İngilizce Açıklama
It is a digital bridge that allows two different software to talk to each other.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/api/)*
