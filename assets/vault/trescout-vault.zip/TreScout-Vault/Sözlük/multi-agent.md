---
title: "Multi-agent"
type: sozluk
category: "ai"
aliases:
  - "Multi-agent"
url: "https://trescout.com/dictionary/multi-agent/"
---

# Multi-agent 

> [!NOTE] Tanım
> Birden fazla yapay zekâlı yazılımın, karmaşık bir görevi bölüşerek ortak bir hedef için iş birliği yapmasıdır.

## İngilizce Açıklama
It is the collaboration of more than one artificial intelligence software for a common goal by dividing a complex task.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/multi-agent/)*
