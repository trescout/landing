---
title: "Few-shot Learning"
type: sozluk
category: "ai"
aliases:
  - "Few-shot Learning"
url: "https://trescout.com/dictionary/few-shot-learning/"
---

# Few-shot Learning 

> [!NOTE] Tanım
> Yapay zekanın çok az örnekle yeni bir görevi öğrenme yeteneğidir.

## İngilizce Açıklama
It is the ability of artificial intelligence to learn a new task with very few examples.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/few-shot-learning/)*
