---
title: "Desktop Client"
type: sozluk
category: "dev"
aliases:
  - "Desktop Client"
url: "https://trescout.com/dictionary/desktop-client/"
---

# Desktop Client 

> [!NOTE] Tanım
> Bilgisayarınıza yükleyerek doğrudan masaüstü ortamında çalıştırdığınız yazılım uygulamasıdır.

## İngilizce Açıklama
It is a software application that you install on your computer and run directly in the desktop environment.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/desktop-client/)*
