---
title: "IT Automation"
type: sozluk
category: "dev"
aliases:
  - "IT Automation"
url: "https://trescout.com/dictionary/it-automation/"
---

# IT Automation 

> [!NOTE] Tanım
> Bilgisayar sistemlerindeki rutin ve tekrarlanan görevlerin yazılımlar tarafından insana ihtiyaç duymadan yürütülmesidir.

## İngilizce Açıklama
Routine and repetitive tasks in computer systems are carried out by software without the need for humans.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/it-automation/)*
