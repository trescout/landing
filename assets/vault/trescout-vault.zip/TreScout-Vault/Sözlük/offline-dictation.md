---
title: "Offline Dictation"
type: sozluk
category: "ai"
aliases:
  - "Offline Dictation"
url: "https://trescout.com/dictionary/offline-dictation/"
---

# Offline Dictation 

> [!NOTE] Tanım
> İnternet bağlantısı gerektirmeden, konuşulanları anlık olarak metne dönüştüren teknolojidir.

## İngilizce Açıklama
It is a technology that instantly converts spoken words into text without requiring an internet connection.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/offline-dictation/)*
