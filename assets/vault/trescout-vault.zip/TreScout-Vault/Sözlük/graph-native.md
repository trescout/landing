---
title: "Graph-native"
type: sozluk
category: "data"
aliases:
  - "Graph-native"
url: "https://trescout.com/dictionary/graph-native/"
---

# Graph-native 

> [!NOTE] Tanım
> Verilerin birbirine düğümlerle bağlı olduğu bir yapıyı temel alan sistem tasarımıdır.

## İngilizce Açıklama
It is a system design based on a structure in which data is connected to each other through nodes.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/graph-native/)*
