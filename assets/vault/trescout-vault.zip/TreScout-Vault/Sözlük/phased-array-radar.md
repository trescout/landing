---
title: "Phased Array Radar"
type: sozluk
category: "dev"
aliases:
  - "Phased Array Radar"
url: "https://trescout.com/dictionary/phased-array-radar/"
---

# Phased Array Radar 

> [!NOTE] Tanım
> Hareketli parçalar kullanmadan, elektronik sinyallerle yönünü değiştirerek hedefleri takip eden gelişmiş bir radar sistemidir.

## İngilizce Açıklama
It is an advanced radar system that tracks targets by changing their direction with electronic signals, without using moving parts.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/phased-array-radar/)*
