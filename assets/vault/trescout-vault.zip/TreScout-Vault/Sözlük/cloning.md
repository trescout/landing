---
title: "Cloning"
type: sozluk
category: "dev"
aliases:
  - "Cloning"
url: "https://trescout.com/dictionary/cloning/"
---

# Cloning 

> [!NOTE] Tanım
> Bir yazılım projesinin veya verinin tamamını başka bir yere kopyalayarak çoğaltma işlemidir.

## İngilizce Açıklama
It is the process of duplicating a software project or entire data by copying it to another location.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/cloning/)*
