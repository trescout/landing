---
title: "Bundler"
type: sozluk
category: "dev"
aliases:
  - "Bundler"
url: "https://trescout.com/dictionary/bundler/"
---

# Bundler 

> [!NOTE] Tanım
> Yazılım projesindeki çok sayıda dosyayı birleştirip optimize ederek tarayıcıların çalıştırabileceği tek bir yapıya dönüştüren araçtır.

## İngilizce Açıklama
It is a tool that combines and optimizes multiple files in a software project and turns them into a single structure that browsers can run.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bundler/)*
