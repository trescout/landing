---
title: "Clone"
type: sozluk
category: "dev"
aliases:
  - "Clone"
url: "https://trescout.com/dictionary/clone/"
---

# Clone 

> [!NOTE] Tanım
> İnternetteki bir yazılım projesinin tüm dosyalarını ve geçmişini kendi bilgisayarınıza kopyalama işlemidir.

## İngilizce Açıklama
It is the process of copying all the files and history of a software project on the Internet to your own computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/clone/)*
