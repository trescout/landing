---
title: "Server-side Rendering"
type: sozluk
category: "dev"
aliases:
  - "Server-side Rendering"
  - "SSR"
url: "https://trescout.com/dictionary/server-side-rendering/"
---

# Server-side Rendering (SSR)

> [!NOTE] Tanım
> Web sayfalarının kullanıcıya gönderilmeden önce sunucuda hazırlanıp hızlıca görüntülenmesini sağlayan yöntemdir.

## İngilizce Açıklama
It is a method that allows web pages to be prepared on the server and displayed quickly before being sent to the user.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/server-side-rendering/)*
