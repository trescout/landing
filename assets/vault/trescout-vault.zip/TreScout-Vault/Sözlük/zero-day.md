---
title: "Zero-day Exploit"
type: sozluk
category: "dev"
aliases:
  - "Zero-day Exploit"
url: "https://trescout.com/dictionary/zero-day/"
---

# Zero-day Exploit 

> [!NOTE] Tanım
> Henüz çözümü bulunmamış, yeni keşfedilen güvenlik açığıdır.

## İngilizce Açıklama
It is a newly discovered security vulnerability that has not yet been resolved.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/zero-day/)*
