---
title: "Packet Fragmentation"
type: sozluk
category: "dev"
aliases:
  - "Packet Fragmentation"
url: "https://trescout.com/dictionary/packet-fragmentation/"
---

# Packet Fragmentation 

> [!NOTE] Tanım
> İnternet üzerinden gönderilen verilerin, ağın taşıma kapasitesine göre daha küçük parçalara bölünmesi işlemidir.

## İngilizce Açıklama
It is the process of dividing the data sent over the Internet into smaller pieces according to the carrying capacity of the network.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/packet-fragmentation/)*
