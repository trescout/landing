---
title: "Omni-channel Desk"
type: sozluk
category: "ai"
aliases:
  - "Omni-channel Desk"
url: "https://trescout.com/dictionary/omni-channel-desk/"
---

# Omni-channel Desk 

> [!NOTE] Tanım
> Müşterilerden gelen e-posta, mesaj ve çağrı gibi tüm farklı iletişim kanallarını tek bir ekranda toplayan destek sistemidir.

## İngilizce Açıklama
It is a support system that collects all different communication channels such as e-mails, messages and calls from customers on a single screen.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/omni-channel-desk/)*
