---
title: "Secrets"
type: sozluk
category: "dev"
aliases:
  - "Secrets"
url: "https://trescout.com/dictionary/secrets/"
---

# Secrets 

> [!NOTE] Tanım
> Yazılım uygulamalarının güvenli bir şekilde çalışması için ihtiyaç duyduğu şifreler, API anahtarları ve erişim kodlarıdır.

## İngilizce Açıklama
These are the passwords, API keys and access codes that software applications need to operate securely.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/secrets/)*
