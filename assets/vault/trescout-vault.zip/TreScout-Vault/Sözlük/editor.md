---
title: "Editor"
type: sozluk
category: "dev"
aliases:
  - "Editor"
url: "https://trescout.com/dictionary/editor/"
---

# Editor 

> [!NOTE] Tanım
> Yazılımcıların kod yazmak, düzenlemek ve hataları ayıklamak için kullandığı özel bir yazı programıdır.

## İngilizce Açıklama
It is a special writing program used by software developers to write, edit and debug code.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/editor/)*
