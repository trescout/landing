---
title: "Observability"
type: sozluk
category: "dev"
aliases:
  - "Observability"
url: "https://trescout.com/dictionary/observability/"
---

# Observability 

> [!NOTE] Tanım
> Bir sistemin iç durumunu dışarıdan gelen verilerle izleme yeteneğidir.

## İngilizce Açıklama
It is the ability to monitor the internal state of a system with external data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/observability/)*
