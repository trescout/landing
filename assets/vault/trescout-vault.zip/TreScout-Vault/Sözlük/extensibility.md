---
title: "Extensibility"
type: sozluk
category: "dev"
aliases:
  - "Extensibility"
url: "https://trescout.com/dictionary/extensibility/"
---

# Extensibility 

> [!NOTE] Tanım
> Bir sistemin temel yapısı bozulmadan yeni özellikler eklenerek geliştirilmeye uygun olması.

## İngilizce Açıklama
The suitability of a system to be developed by adding new features without disrupting its basic structure.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/extensibility/)*
