---
title: "AI Agent"
type: sozluk
category: "ai"
aliases:
  - "AI Agent"
url: "https://trescout.com/dictionary/ai-agent/"
---

# AI Agent 

> [!NOTE] Tanım
> Kendi başına karar verip görevleri yerine getiren otonom yapay zekâ sistemidir.

## İngilizce Açıklama
It is an autonomous artificial intelligence system that makes decisions and performs tasks on its own.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/ai-agent/)*
