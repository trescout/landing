---
title: "Terminal"
type: sozluk
category: "dev"
aliases:
  - "Terminal"
url: "https://trescout.com/dictionary/terminal/"
---

# Terminal 

> [!NOTE] Tanım
> Bilgisayarınızla fare kullanmadan, sadece metin komutları yazarak doğrudan iletişim kurmanızı sağlayan siyah ekranlı arayüzdür.

## İngilizce Açıklama
It is a black-screen interface that allows you to communicate directly with your computer without using a mouse, just by typing text commands.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/terminal/)*
