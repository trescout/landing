---
title: "Meta-framework"
type: sozluk
category: "dev"
aliases:
  - "Meta-framework"
url: "https://trescout.com/dictionary/meta-framework/"
---

# Meta-framework 

> [!NOTE] Tanım
> Temel yazılım araçlarının üzerine inşa edilen, kapsamlı geliştirme platformudur.

## İngilizce Açıklama
It is a comprehensive development platform built on core software tools.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/meta-framework/)*
