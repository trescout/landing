---
title: "Data Layer"
type: sozluk
category: "dev"
aliases:
  - "Data Layer"
url: "https://trescout.com/dictionary/data-layer/"
---

# Data Layer 

> [!NOTE] Tanım
> Uygulamanızın veritabanı ile konuşmasını sağlayan, veriyi düzenleyen orta katmandır.

## İngilizce Açıklama
It is the middle layer that allows your application to talk to the database and organizes the data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/data-layer/)*
