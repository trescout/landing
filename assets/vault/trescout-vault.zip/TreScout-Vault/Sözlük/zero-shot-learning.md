---
title: "Zero-shot Learning"
type: sozluk
category: "ai"
aliases:
  - "Zero-shot Learning"
url: "https://trescout.com/dictionary/zero-shot-learning/"
---

# Zero-shot Learning 

> [!NOTE] Tanım
> Yapay zekanın hiç eğitim almadığı bir konuyu tahmin etme yeteneğidir.

## İngilizce Açıklama
It is the ability of artificial intelligence to predict something for which it has no training.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/zero-shot-learning/)*
