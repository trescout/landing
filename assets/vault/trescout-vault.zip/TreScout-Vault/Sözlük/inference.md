---
title: "Inference"
type: sozluk
category: "ai"
aliases:
  - "Inference"
url: "https://trescout.com/dictionary/inference/"
---

# Inference 

> [!NOTE] Tanım
> Eğitilmiş bir yapay zekâ modelinin yeni veriler üzerinde tahmin yürütme sürecidir.

## İngilizce Açıklama
It is the process of a trained artificial intelligence model making predictions on new data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/inference/)*
