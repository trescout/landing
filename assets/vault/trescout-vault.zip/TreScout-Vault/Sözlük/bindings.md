---
title: "Bindings"
type: sozluk
category: "dev"
aliases:
  - "Bindings"
url: "https://trescout.com/dictionary/bindings/"
---

# Bindings 

> [!NOTE] Tanım
> Farklı programlama dillerinin birbirinin kütüphanelerini kullanabilmesini sağlayan köprülerdir.

## İngilizce Açıklama
They are bridges that enable different programming languages ​​to use each other's libraries.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/bindings/)*
