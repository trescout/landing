---
title: "State Kernel"
type: sozluk
category: "dev"
aliases:
  - "State Kernel"
url: "https://trescout.com/dictionary/state-kernel/"
---

# State Kernel 

> [!NOTE] Tanım
> Bir yazılımın o anki tüm çalışma bilgilerini ve verilerini bellekte tutan temel çekirdek yapısıdır.

## İngilizce Açıklama
It is the basic core structure that keeps all the current working information and data of a software in memory.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/state-kernel/)*
