---
title: "Agent-native"
type: sozluk
category: "ai"
aliases:
  - "Agent-native"
url: "https://trescout.com/dictionary/agent-native/"
---

# Agent-native 

> [!NOTE] Tanım
> Sistemlerin insan komutu beklemeden, özerk karar alacak şekilde tasarlanmasıdır.

## İngilizce Açıklama
Systems are designed to make autonomous decisions without waiting for human commands.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agent-native/)*
