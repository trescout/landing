---
title: "Monorepo"
type: sozluk
category: "dev"
aliases:
  - "Monorepo"
url: "https://trescout.com/dictionary/monorepo/"
---

# Monorepo 

> [!NOTE] Tanım
> Birden fazla yazılım projesinin tek bir ortak klasörde tutulduğu geliştirme yöntemi.

## İngilizce Açıklama
A development method where multiple software projects are kept in a single shared folder.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/monorepo/)*
