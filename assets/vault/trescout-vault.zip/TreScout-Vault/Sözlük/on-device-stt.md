---
title: "On-device STT"
type: sozluk
category: "ai"
aliases:
  - "On-device STT"
  - "On-device Speech-to-Text"
url: "https://trescout.com/dictionary/on-device-stt/"
---

# On-device STT (On-device Speech-to-Text)

> [!NOTE] Tanım
> İnternet gerekmeden, sesi doğrudan cihaz üzerinde metne dönüştüren teknolojidir.

## İngilizce Açıklama
It is a technology that converts audio into text directly on the device, without the need for internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/on-device-stt/)*
