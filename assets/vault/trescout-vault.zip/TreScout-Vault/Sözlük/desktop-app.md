---
title: "Desktop App"
type: sozluk
category: "dev"
aliases:
  - "Desktop App"
url: "https://trescout.com/dictionary/desktop-app/"
---

# Desktop App 

> [!NOTE] Tanım
> İnternet tarayıcısına ihtiyaç duymadan doğrudan bilgisayarınızın işletim sistemi üzerinde çalışan yazılımlardır.

## İngilizce Açıklama
They are software that runs directly on your computer's operating system without the need for an internet browser.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/desktop-app/)*
