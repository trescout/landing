---
title: "Browser State"
type: sozluk
category: "dev"
aliases:
  - "Browser State"
url: "https://trescout.com/dictionary/browser-state/"
---

# Browser State 

> [!NOTE] Tanım
> İnternet tarayıcınızın o anki oturumunda aktif olan tüm verilerin ve ayarların kaydedildiği durumdur.

## İngilizce Açıklama
It is the state in which all data and settings active in the current session of your internet browser are saved.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/browser-state/)*
