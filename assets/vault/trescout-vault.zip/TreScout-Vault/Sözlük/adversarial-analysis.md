---
title: "Adversarial Analysis"
type: sozluk
category: "dev"
aliases:
  - "Adversarial Analysis"
url: "https://trescout.com/dictionary/adversarial-analysis/"
---

# Adversarial Analysis 

> [!NOTE] Tanım
> Bir sistemin zayıf noktalarını bulmak için kötü niyetli saldırıları taklit ederek yapılan güvenlik testidir.

## İngilizce Açıklama
It is security testing performed by imitating malicious attacks to find the weak points of a system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/adversarial-analysis/)*
