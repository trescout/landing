---
title: "Self-hostable"
type: sozluk
category: "dev"
aliases:
  - "Self-hostable"
url: "https://trescout.com/dictionary/self-hostable/"
---

# Self-hostable 

> [!NOTE] Tanım
> Bir yazılımın dışarıdan hizmet almak yerine kendi altyapınızda çalıştırılabilir olmasıdır.

## İngilizce Açıklama
It means that a software can be run on your own infrastructure instead of outsourcing it.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/self-hostable/)*
