---
title: "Live Transcription"
type: sozluk
category: "ai"
aliases:
  - "Live Transcription"
url: "https://trescout.com/dictionary/live-transcription/"
---

# Live Transcription 

> [!NOTE] Tanım
> Konuşulan sesin anlık olarak metne dönüştürülüp eşzamanlı olarak ekranda gösterilmesi sürecidir.

## İngilizce Açıklama
It is the process of instantly converting spoken audio into text and displaying it on the screen simultaneously.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/live-transcription/)*
