---
title: "Multi-agent LLM"
type: sozluk
category: "ai"
aliases:
  - "Multi-agent LLM"
url: "https://trescout.com/dictionary/multi-agent-llm/"
---

# Multi-agent LLM 

> [!NOTE] Tanım
> Birden fazla yapay zekâ modelinin iş birliği yaparak karmaşık görevleri çözdüğü bir çalışma sistemidir.

## İngilizce Açıklama
It is a working system in which multiple artificial intelligence models cooperate to solve complex tasks.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/multi-agent-llm/)*
