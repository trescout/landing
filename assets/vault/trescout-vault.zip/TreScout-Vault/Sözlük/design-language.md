---
title: "Design Language"
type: sozluk
category: "dev"
aliases:
  - "Design Language"
url: "https://trescout.com/dictionary/design-language/"
---

# Design Language 

> [!NOTE] Tanım
> Bir ürünün görsel dünyasını ve kullanıcı deneyimini tutarlı kılan kurallar bütünüdür.

## İngilizce Açıklama
It is a set of rules that keeps the visual world and user experience of a product consistent.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/design-language/)*
