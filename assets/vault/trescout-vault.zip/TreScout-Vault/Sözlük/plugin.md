---
title: "Plugin"
type: sozluk
category: "dev"
aliases:
  - "Plugin"
url: "https://trescout.com/dictionary/plugin/"
---

# Plugin 

> [!NOTE] Tanım
> Ana programa ek özellikler kazandırmak için sonradan yüklenen küçük yazılım parçaları.

## İngilizce Açıklama
Small pieces of software that are installed later to provide additional features to the main program.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/plugin/)*
