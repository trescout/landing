---
title: "Optical Character Recognition"
type: sozluk
category: "data"
aliases:
  - "Optical Character Recognition"
  - "OCR"
url: "https://trescout.com/dictionary/optical-character-recognition/"
---

# Optical Character Recognition (OCR)

> [!NOTE] Tanım
> Görsel haldeki metinleri bilgisayarın düzenleyebileceği dijital yazıya dönüştüren teknoloji.

## İngilizce Açıklama
Technology that converts visual texts into digital text that can be edited by a computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/optical-character-recognition/)*
