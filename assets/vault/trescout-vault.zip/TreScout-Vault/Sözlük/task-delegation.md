---
title: "Task Delegation"
type: sozluk
category: "ai"
aliases:
  - "Task Delegation"
url: "https://trescout.com/dictionary/task-delegation/"
---

# Task Delegation 

> [!NOTE] Tanım
> Bir işin tamamlanması için sorumluluğun başka bir kişiye veya yapay zekâ sistemine devredilmesidir.

## İngilizce Açıklama
It is the transfer of responsibility for the completion of a job to another person or artificial intelligence system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/task-delegation/)*
