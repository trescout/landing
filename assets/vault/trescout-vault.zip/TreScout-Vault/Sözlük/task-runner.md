---
title: "Task Runner"
type: sozluk
category: "dev"
aliases:
  - "Task Runner"
url: "https://trescout.com/dictionary/task-runner/"
---

# Task Runner 

> [!NOTE] Tanım
> Tekrarlayan yazılım görevlerini otomatik olarak sırayla çalıştıran yardımcı araçtır.

## İngilizce Açıklama
It is a utility tool that automatically runs repetitive software tasks sequentially.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/task-runner/)*
