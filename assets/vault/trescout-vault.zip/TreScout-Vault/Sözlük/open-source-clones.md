---
title: "Open-Source Clones"
type: sozluk
category: "dev"
aliases:
  - "Open-Source Clones"
url: "https://trescout.com/dictionary/open-source-clones/"
---

# Open-Source Clones 

> [!NOTE] Tanım
> Popüler yazılımların kaynak kodlarının herkesin erişimine açık şekilde kopyalanarak oluşturulan benzerleridir.

## İngilizce Açıklama
They are similar versions of popular software created by publicly copying their source codes.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/open-source-clones/)*
