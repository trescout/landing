---
title: "Transcription"
type: sozluk
category: "ai"
aliases:
  - "Transcription"
url: "https://trescout.com/dictionary/transcription/"
---

# Transcription 

> [!NOTE] Tanım
> Sesli konuşmaların veya kayıtların yapay zekâ tarafından analiz edilerek yazılı metne dönüştürülmesi işlemidir.

## İngilizce Açıklama
It is the process of analyzing voice conversations or recordings by artificial intelligence and converting them into written text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/transcription/)*
