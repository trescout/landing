---
title: "OIDC"
type: sozluk
category: "dev"
aliases:
  - "OIDC"
  - "OpenID Connect"
url: "https://trescout.com/dictionary/oidc/"
---

# OIDC (OpenID Connect)

> [!NOTE] Tanım
> Farklı sitelere giriş yaparken kimliğinizi güvenli bir şekilde doğrulayan standart bir protokoldür.

## İngilizce Açıklama
It is a standard protocol that securely verifies your identity when logging into different sites.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/oidc/)*
