---
title: "Batch Processing"
type: sozluk
category: "dev"
aliases:
  - "Batch Processing"
url: "https://trescout.com/dictionary/batch-processing/"
---

# Batch Processing 

> [!NOTE] Tanım
> Çok sayıda işlemin tek tek değil, bir grup halinde arka planda otomatik olarak gerçekleştirilmesidir.

## İngilizce Açıklama
It is the automatic execution of many operations in the background as a group, rather than one by one.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/batch-processing/)*
