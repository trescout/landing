---
title: "Keybindings"
type: sozluk
category: "dev"
aliases:
  - "Keybindings"
url: "https://trescout.com/dictionary/keybindings/"
---

# Keybindings 

> [!NOTE] Tanım
> Klavye tuşlarına belirli görevlerin veya komutların atanması işlemidir.

## İngilizce Açıklama
It is the process of assigning specific tasks or commands to keyboard keys.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/keybindings/)*
