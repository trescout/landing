---
title: "Identity Provider"
type: sozluk
category: "dev"
aliases:
  - "Identity Provider"
url: "https://trescout.com/dictionary/identity-provider/"
---

# Identity Provider 

> [!NOTE] Tanım
> Kullanıcı giriş bilgilerini doğrulayan ve uygulamalara güvenli erişim sağlayan merkezi servis.

## İngilizce Açıklama
Central service that verifies user login information and provides secure access to applications.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/identity-provider/)*
