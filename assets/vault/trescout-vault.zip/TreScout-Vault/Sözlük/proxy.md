---
title: "Proxy"
type: sozluk
category: "dev"
aliases:
  - "Proxy"
url: "https://trescout.com/dictionary/proxy/"
---

# Proxy 

> [!NOTE] Tanım
> İnternet üzerindeki işlemlerinizi sizin yerinize yapan bir aracı sunucudur.

## İngilizce Açıklama
It is an intermediary server that performs your transactions on the Internet on your behalf.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/proxy/)*
