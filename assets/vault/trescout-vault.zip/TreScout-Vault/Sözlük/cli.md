---
title: "CLI"
type: sozluk
category: "dev"
aliases:
  - "CLI"
  - "Command Line Interface"
url: "https://trescout.com/dictionary/cli/"
---

# CLI (Command Line Interface)

> [!NOTE] Tanım
> Bilgisayara komutları yazılı metinler ile verme yöntemidir.

## İngilizce Açıklama
It is a method of giving commands to the computer through written texts.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/cli/)*
