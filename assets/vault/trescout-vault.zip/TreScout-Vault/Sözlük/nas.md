---
title: "NAS"
type: sozluk
category: "data"
aliases:
  - "NAS"
  - "Network Attached Storage"
url: "https://trescout.com/dictionary/nas/"
---

# NAS (Network Attached Storage)

> [!NOTE] Tanım
> Ev veya ofis ağındaki tüm cihazların ortaklaşa kullanabileceği, merkezi bir depolama alanı sunan cihaz.

## İngilizce Açıklama
A device that provides a central storage area that can be shared by all devices in the home or office network.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/nas/)*
