---
title: "Notebooks"
type: sozluk
category: "dev"
aliases:
  - "Notebooks"
url: "https://trescout.com/dictionary/notebooks/"
---

# Notebooks 

> [!NOTE] Tanım
> Kod yazarken notlar alıp sonuçları anında görebileceğiniz etkileşimli çalışma ortamlarıdır.

## İngilizce Açıklama
They are interactive work environments where you can take notes while writing code and see the results instantly.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/notebooks/)*
