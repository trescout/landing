---
title: "BYOK"
type: sozluk
category: "dev"
aliases:
  - "BYOK"
  - "Bring Your Own Key"
url: "https://trescout.com/dictionary/byok/"
---

# BYOK (Bring Your Own Key)

> [!NOTE] Tanım
> Kullanıcının kendi verilerini şifrelemek için kendi güvenlik anahtarlarını getirmesine izin veren bir güvenlik yaklaşımıdır.

## İngilizce Açıklama
It is a security approach that allows the user to bring their own security keys to encrypt their own data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/byok/)*
