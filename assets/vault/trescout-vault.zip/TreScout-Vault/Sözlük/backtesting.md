---
title: "Backtesting"
type: sozluk
category: "data"
aliases:
  - "Backtesting"
url: "https://trescout.com/dictionary/backtesting/"
---

# Backtesting 

> [!NOTE] Tanım
> Bir yatırım stratejisinin geçmişteki piyasa verileri kullanılarak ne kadar başarılı olacağını test etme yöntemidir.

## İngilizce Açıklama
It is a method of testing how successful an investment strategy will be using historical market data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/backtesting/)*
