---
title: "Personalized Tutoring"
type: sozluk
category: "ai"
aliases:
  - "Personalized Tutoring"
url: "https://trescout.com/dictionary/personalized-tutoring/"
---

# Personalized Tutoring 

> [!NOTE] Tanım
> Öğrencinin anlama hızına ve eksiklerine göre uyarlanan yapay zekâ destekli özel eğitim.

## İngilizce Açıklama
Artificial intelligence-supported special education adapted to the student's understanding speed and deficiencies.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/personalized-tutoring/)*
