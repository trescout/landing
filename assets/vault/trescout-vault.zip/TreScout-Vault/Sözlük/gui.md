---
title: "GUI"
type: sozluk
category: "dev"
aliases:
  - "GUI"
  - "Graphical User Interface"
url: "https://trescout.com/dictionary/gui/"
---

# GUI (Graphical User Interface)

> [!NOTE] Tanım
> Bilgisayar programlarını metin yazmak yerine simgeler, menüler ve pencerelerle görsel olarak yönetmenizi sağlayan arayüzdür.

## İngilizce Açıklama
It is an interface that allows you to manage computer programs visually with icons, menus and windows instead of typing text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/gui/)*
