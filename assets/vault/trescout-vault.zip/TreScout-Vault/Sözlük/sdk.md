---
title: "SDK"
type: sozluk
category: "dev"
aliases:
  - "SDK"
  - "Software Development Kit"
url: "https://trescout.com/dictionary/sdk/"
---

# SDK (Software Development Kit)

> [!NOTE] Tanım
> Yazılımcıların belirli bir platform için uygulama geliştirmesini kolaylaştıran araçlar ve kütüphaneler bütünüdür.

## İngilizce Açıklama
It is a set of tools and libraries that make it easier for software developers to develop applications for a specific platform.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/sdk/)*
