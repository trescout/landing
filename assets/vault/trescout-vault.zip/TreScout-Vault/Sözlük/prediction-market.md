---
title: "Prediction Market"
type: sozluk
category: "data"
aliases:
  - "Prediction Market"
url: "https://trescout.com/dictionary/prediction-market/"
---

# Prediction Market 

> [!NOTE] Tanım
> Gelecekteki olayların sonuçlarını tahmin etmek için oluşturulan pazar yeridir.

## İngilizce Açıklama
It is a marketplace created to predict the outcomes of future events.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/prediction-market/)*
