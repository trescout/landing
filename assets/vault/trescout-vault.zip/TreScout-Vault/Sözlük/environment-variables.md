---
title: "Environment Variables"
type: sozluk
category: "dev"
aliases:
  - "Environment Variables"
url: "https://trescout.com/dictionary/environment-variables/"
---

# Environment Variables 

> [!NOTE] Tanım
> Programların çalışma anında ihtiyaç duyduğu ayarları ve gizli anahtarları tutan küçük tanımlayıcılardır.

## İngilizce Açıklama
They are small identifiers that hold the settings and secret keys that programs need at run time.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/environment-variables/)*
