---
title: "System Prompt Leaks"
type: sozluk
category: "ai"
aliases:
  - "System Prompt Leaks"
url: "https://trescout.com/dictionary/system-prompt-leaks/"
---

# System Prompt Leaks 

> [!NOTE] Tanım
> Yapay zekanın gizli talimatlarının kullanıcı tarafından ortaya çıkarılmasıdır.

## İngilizce Açıklama
It is the revealing of the hidden instructions of artificial intelligence by the user.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/system-prompt-leaks/)*
