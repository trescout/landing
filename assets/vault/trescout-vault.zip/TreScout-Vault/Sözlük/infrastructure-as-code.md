---
title: "Infrastructure as Code"
type: sozluk
category: "dev"
aliases:
  - "Infrastructure as Code"
  - "IaC"
url: "https://trescout.com/dictionary/infrastructure-as-code/"
---

# Infrastructure as Code (IaC)

> [!NOTE] Tanım
> Sunucu ve ağ gibi sistem kurulumlarını elle yapmak yerine, kod dosyaları yazarak otomatikleştirme yöntemi.

## İngilizce Açıklama
A method of automating system installations such as server and network by writing code files instead of doing them manually.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/infrastructure-as-code/)*
