---
title: "Single Source of Truth"
type: sozluk
category: "data"
aliases:
  - "Single Source of Truth"
  - "SSOT"
url: "https://trescout.com/dictionary/single-source-of-truth/"
---

# Single Source of Truth (SSOT)

> [!NOTE] Tanım
> Tüm verilerin tek bir güvenilir merkezden yönetilmesi ve herkesin aynı bilgiye ulaşması prensibidir.

## İngilizce Açıklama
It is the principle that all data is managed from a single reliable center and everyone has access to the same information.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/single-source-of-truth/)*
