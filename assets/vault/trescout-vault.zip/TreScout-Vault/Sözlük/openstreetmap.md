---
title: "OpenStreetMap"
type: sozluk
category: "data"
aliases:
  - "OpenStreetMap"
url: "https://trescout.com/dictionary/openstreetmap/"
---

# OpenStreetMap 

> [!NOTE] Tanım
> Dünya üzerindeki herkesin katkıda bulunabildiği ücretsiz ve açık kaynaklı bir harita projesidir.

## İngilizce Açıklama
It is a free and open source map project that anyone in the world can contribute to.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/openstreetmap/)*
