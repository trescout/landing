---
title: "Multimodal AI"
type: sozluk
category: "ai"
aliases:
  - "Multimodal AI"
url: "https://trescout.com/dictionary/multimodal-ai/"
---

# Multimodal AI 

> [!NOTE] Tanım
> Yapay zekânın sadece metinle değil; görüntü, ses ve video gibi farklı veri türlerini aynı anda işleyebilme yeteneğidir.

## İngilizce Açıklama
Artificial intelligence works not only with text; It is the ability to process different types of data such as images, audio and video simultaneously.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/multimodal-ai/)*
