---
title: "WiFi"
type: sozluk
category: "dev"
aliases:
  - "WiFi"
  - "Wireless Fidelity"
url: "https://trescout.com/dictionary/wifi/"
---

# WiFi (Wireless Fidelity)

> [!NOTE] Tanım
> Cihazların kabloya ihtiyaç duymadan radyo dalgaları aracılığıyla internete bağlanmasını sağlayan teknolojidir.

## İngilizce Açıklama
It is the technology that allows devices to connect to the internet via radio waves without the need for cables.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/wifi/)*
