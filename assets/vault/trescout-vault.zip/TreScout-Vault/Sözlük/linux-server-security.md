---
title: "Linux Server Security"
type: sozluk
category: "dev"
aliases:
  - "Linux Server Security"
url: "https://trescout.com/dictionary/linux-server-security/"
---

# Linux Server Security 

> [!NOTE] Tanım
> Açık kaynaklı sunucu sistemlerini siber tehditlere karşı güçlendirme ve koruma disiplinidir.

## İngilizce Açıklama
It is the discipline of strengthening and protecting open source server systems against cyber threats.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/linux-server-security/)*
