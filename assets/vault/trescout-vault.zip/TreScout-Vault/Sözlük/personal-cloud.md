---
title: "Personal Cloud"
type: sozluk
category: "data"
aliases:
  - "Personal Cloud"
url: "https://trescout.com/dictionary/personal-cloud/"
---

# Personal Cloud 

> [!NOTE] Tanım
> Kişisel dosyaların internet üzerinden her yerden erişilebilecek şekilde özel bir alanda saklanmasıdır.

## İngilizce Açıklama
It is the storage of personal files in a private area that can be accessed from anywhere over the internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/personal-cloud/)*
