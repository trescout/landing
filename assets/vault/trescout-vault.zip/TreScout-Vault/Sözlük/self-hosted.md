---
title: "Self-hosted"
type: sozluk
category: "dev"
aliases:
  - "Self-hosted"
url: "https://trescout.com/dictionary/self-hosted/"
---

# Self-hosted 

> [!NOTE] Tanım
> Bir yazılımı üçüncü taraf bir bulut hizmeti yerine, kendi bilgisayarınızda veya özel sunucunuzda barındırmaktır.

## İngilizce Açıklama
It is hosting a software on your own computer or dedicated server rather than on a third-party cloud service.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/self-hosted/)*
