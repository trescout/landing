---
title: "Networking Stack"
type: sozluk
category: "dev"
aliases:
  - "Networking Stack"
url: "https://trescout.com/dictionary/networking-stack/"
---

# Networking Stack 

> [!NOTE] Tanım
> Bilgisayarların birbirleriyle iletişim kurmasını sağlayan yazılım ve protokollerin katmanlı yapısıdır.

## İngilizce Açıklama
It is the layered structure of software and protocols that enable computers to communicate with each other.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/networking-stack/)*
