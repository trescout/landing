---
title: "Autonomous Agent"
type: sozluk
category: "ai"
aliases:
  - "Autonomous Agent"
url: "https://trescout.com/dictionary/autonomous-agent/"
---

# Autonomous Agent 

> [!NOTE] Tanım
> İnsan müdahalesi olmadan kendi başına hedefler belirleyip bu hedeflere ulaşmak için gerekli adımları atan yazılımdır.

## İngilizce Açıklama
It is software that sets goals on its own, without human intervention, and takes the necessary steps to achieve these goals.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/autonomous-agent/)*
