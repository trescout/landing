---
title: "Logs"
type: sozluk
category: "dev"
aliases:
  - "Logs"
url: "https://trescout.com/dictionary/logs/"
---

# Logs 

> [!NOTE] Tanım
> Bir yazılımın arka planda yaptığı işlemlerin ve karşılaştığı hataların zaman damgasıyla tutulan kayıtlarıdır.

## İngilizce Açıklama
They are time-stamped records of the operations a software performs in the background and the errors it encounters.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/logs/)*
