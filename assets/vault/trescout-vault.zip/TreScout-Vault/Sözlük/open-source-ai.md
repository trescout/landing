---
title: "Open Source AI"
type: sozluk
category: "ai"
aliases:
  - "Open Source AI"
url: "https://trescout.com/dictionary/open-source-ai/"
---

# Open Source AI 

> [!NOTE] Tanım
> Kodları, model ağırlıkları ve çalışma mantığı herkesin incelemesine, değiştirmesine ve geliştirmesine açık olan yapay zekâ modelleridir.

## İngilizce Açıklama
They are artificial intelligence models whose codes, model weights and working logic are open to anyone to examine, change and improve.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/open-source-ai/)*
