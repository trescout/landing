---
title: "Plugin Specification"
type: sozluk
category: "dev"
aliases:
  - "Plugin Specification"
url: "https://trescout.com/dictionary/plugin-specification/"
---

# Plugin Specification 

> [!NOTE] Tanım
> Bir yazılıma dışarıdan eklenti geliştirmek için uyulması gereken teknik kurallar bütünüdür.

## İngilizce Açıklama
It is a set of technical rules that must be followed to develop external add-ons for a software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/plugin-specification/)*
