---
title: "Code Splitting"
type: sozluk
category: "dev"
aliases:
  - "Code Splitting"
url: "https://trescout.com/dictionary/code-splitting/"
---

# Code Splitting 

> [!NOTE] Tanım
> Web sitesinin yüklenme hızını artırmak için büyük kod dosyalarını küçük parçalara bölüp sadece ihtiyaç anında yükleme yöntemidir.

## İngilizce Açıklama
In order to increase the loading speed of the website, it is a method of dividing large code files into small pieces and loading them only when needed.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/code-splitting/)*
