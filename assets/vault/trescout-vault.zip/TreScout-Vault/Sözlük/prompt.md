---
title: "Prompt"
type: sozluk
category: "ai"
aliases:
  - "Prompt"
url: "https://trescout.com/dictionary/prompt/"
---

# Prompt 

> [!NOTE] Tanım
> Yapay zekâdan belirli bir görev yapmasını veya bir soruya cevap vermesini istemek için kullanılan yazılı talimattır.

## İngilizce Açıklama
It is a written instruction used to ask the AI ​​to perform a specific task or answer a question.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/prompt/)*
