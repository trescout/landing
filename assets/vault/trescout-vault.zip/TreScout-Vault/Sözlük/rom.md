---
title: "ROM"
type: sozluk
category: "dev"
aliases:
  - "ROM"
  - "Read-Only Memory"
url: "https://trescout.com/dictionary/rom/"
---

# ROM (Read-Only Memory)

> [!NOTE] Tanım
> Bilgisayar kapandığında bile içindeki bilgileri koruyan, sadece okunabilen kalıcı bellek türüdür.

## İngilizce Açıklama
It is a type of read-only permanent memory that preserves the information inside even when the computer is turned off.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/rom/)*
