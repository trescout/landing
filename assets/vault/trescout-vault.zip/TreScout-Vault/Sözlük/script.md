---
title: "Script"
type: sozluk
category: "dev"
aliases:
  - "Script"
url: "https://trescout.com/dictionary/script/"
---

# Script 

> [!NOTE] Tanım
> Bilgisayara belirli bir işi otomatik olarak yaptırmak için yazılan kısa ve doğrudan çalışan komut dizisidir.

## İngilizce Açıklama
It is a short and direct sequence of commands written to make the computer do a certain job automatically.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/script/)*
