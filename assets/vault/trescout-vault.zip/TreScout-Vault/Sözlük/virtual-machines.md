---
title: "Virtual Machines"
type: sozluk
category: "dev"
aliases:
  - "Virtual Machines"
url: "https://trescout.com/dictionary/virtual-machines/"
---

# Virtual Machines 

> [!NOTE] Tanım
> Bir bilgisayarın içinde, sanki ayrı bir cihazmış gibi çalışan sanal işletim sistemleridir.

## İngilizce Açıklama
They are virtual operating systems that run inside a computer as if it were a separate device.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/virtual-machines/)*
