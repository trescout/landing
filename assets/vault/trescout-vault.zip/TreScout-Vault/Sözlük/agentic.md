---
title: "Agentic"
type: sozluk
category: "ai"
aliases:
  - "Agentic"
url: "https://trescout.com/dictionary/agentic/"
---

# Agentic 

> [!NOTE] Tanım
> Bir yapay zekânın, kendisine verilen hedef doğrultusunda insan müdahalesi olmadan kendi başına plan yapıp aksiyon alabilme yeteneğidir.

## İngilizce Açıklama
It is the ability of an artificial intelligence to plan and take action on its own, without human intervention, in line with the target given to it.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agentic/)*
