---
title: "Resolver Load Balancing"
type: sozluk
category: "dev"
aliases:
  - "Resolver Load Balancing"
url: "https://trescout.com/dictionary/resolver-load-balancing/"
---

# Resolver Load Balancing 

> [!NOTE] Tanım
> İnternet adres sorgularını birden fazla sunucuya dağıtarak sistemin aşırı yüklenmesini önleme işlemidir.

## İngilizce Açıklama
It is the process of preventing system overload by distributing Internet address queries to multiple servers.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/resolver-load-balancing/)*
