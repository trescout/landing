---
title: "Customization"
type: sozluk
category: "dev"
aliases:
  - "Customization"
url: "https://trescout.com/dictionary/customization/"
---

# Customization 

> [!NOTE] Tanım
> Bir yazılımın veya sistemin, kullanıcının özel tercihlerine ve ihtiyaçlarına göre yeniden şekillendirilmesidir.

## İngilizce Açıklama
It is the reshaping of a software or system according to the user's specific preferences and needs.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/customization/)*
