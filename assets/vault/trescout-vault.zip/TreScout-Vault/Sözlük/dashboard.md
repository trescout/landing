---
title: "Dashboard"
type: sozluk
category: "dev"
aliases:
  - "Dashboard"
url: "https://trescout.com/dictionary/dashboard/"
---

# Dashboard 

> [!NOTE] Tanım
> Karmaşık verileri ve istatistikleri tek bir ekranda görsel olarak takip etmenizi sağlayan panel.

## İngilizce Açıklama
Panel that allows you to visually track complex data and statistics on a single screen.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dashboard/)*
