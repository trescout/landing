---
title: "Continuous Integration"
type: sozluk
category: "dev"
aliases:
  - "Continuous Integration"
  - "CI"
url: "https://trescout.com/dictionary/continuous-integration/"
---

# Continuous Integration (CI)

> [!NOTE] Tanım
> Yazılımcıların yazdığı kodların otomatik olarak birleştirilip test edilerek hataların erkenden yakalanmasını sağlayan süreçtir.

## İngilizce Açıklama
It is the process that ensures that errors are caught early by automatically combining and testing the codes written by software developers.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/continuous-integration/)*
