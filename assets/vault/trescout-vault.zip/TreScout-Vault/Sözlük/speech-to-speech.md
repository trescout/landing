---
title: "Speech-to-Speech"
type: sozluk
category: "ai"
aliases:
  - "Speech-to-Speech"
url: "https://trescout.com/dictionary/speech-to-speech/"
---

# Speech-to-Speech 

> [!NOTE] Tanım
> Sesli girdiyi doğrudan sesli çıktıya dönüştüren, metne ihtiyaç duymayan bir teknoloji.

## İngilizce Açıklama
A technology that directly converts voice input into voice output, without the need for text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/speech-to-speech/)*
