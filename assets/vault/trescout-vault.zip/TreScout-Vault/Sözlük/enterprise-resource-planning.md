---
title: "Enterprise Resource Planning"
type: sozluk
category: "dev"
aliases:
  - "Enterprise Resource Planning"
  - "ERP"
url: "https://trescout.com/dictionary/enterprise-resource-planning/"
---

# Enterprise Resource Planning (ERP)

> [!NOTE] Tanım
> Bir şirketin muhasebe, stok, insan kaynakları gibi tüm iş süreçlerini tek bir merkezden yönetmesini sağlayan yazılım sistemidir.

## İngilizce Açıklama
It is a software system that allows a company to manage all business processes such as accounting, inventory and human resources from a single center.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/enterprise-resource-planning/)*
