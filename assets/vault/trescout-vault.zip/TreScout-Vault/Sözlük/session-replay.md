---
title: "Session Replay"
type: sozluk
category: "dev"
aliases:
  - "Session Replay"
url: "https://trescout.com/dictionary/session-replay/"
---

# Session Replay 

> [!NOTE] Tanım
> Kullanıcının web sitenizdeki tüm hareketlerini bir film gibi kaydedip izlemenizi sağlayan teknolojidir.

## İngilizce Açıklama
It is a technology that allows you to record and watch all the user's movements on your website like a movie.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/session-replay/)*
