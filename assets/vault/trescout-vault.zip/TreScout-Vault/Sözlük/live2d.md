---
title: "Live2D"
type: sozluk
category: "ai"
aliases:
  - "Live2D"
url: "https://trescout.com/dictionary/live2d/"
---

# Live2D 

> [!NOTE] Tanım
> İki boyutlu çizimleri üç boyutluymuş gibi hareket ettirerek karakterlere canlılık kazandıran bir teknolojidir.

## İngilizce Açıklama
It is a technology that brings life to characters by moving two-dimensional drawings as if they were three-dimensional.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/live2d/)*
