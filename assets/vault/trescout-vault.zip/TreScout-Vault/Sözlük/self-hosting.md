---
title: "Self-hosting"
type: sozluk
category: "dev"
aliases:
  - "Self-hosting"
url: "https://trescout.com/dictionary/self-hosting/"
---

# Self-hosting 

> [!NOTE] Tanım
> Yazılımları kendi sunucularınızda veya bilgisayarlarınızda barındırma yöntemidir.

## İngilizce Açıklama
It is a method of hosting software on your own servers or computers.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/self-hosting/)*
