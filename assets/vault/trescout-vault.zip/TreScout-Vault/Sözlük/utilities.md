---
title: "Utilities"
type: sozluk
category: "dev"
aliases:
  - "Utilities"
url: "https://trescout.com/dictionary/utilities/"
---

# Utilities 

> [!NOTE] Tanım
> Bilgisayarın bakımını, yönetimini veya temel işlevlerini kolaylaştıran yardımcı küçük yazılımlar.

## İngilizce Açıklama
Helpful small software that facilitates the maintenance, management or basic functions of the computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/utilities/)*
