---
title: "Terminal File Manager"
type: sozluk
category: "dev"
aliases:
  - "Terminal File Manager"
url: "https://trescout.com/dictionary/terminal-file-manager/"
---

# Terminal File Manager 

> [!NOTE] Tanım
> Dosyalarınızı görsel pencereler yerine sadece komut satırı üzerinden yönetmenizi sağlayan araç.

## İngilizce Açıklama
A tool that allows you to manage your files only via the command line instead of visual windows.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/terminal-file-manager/)*
