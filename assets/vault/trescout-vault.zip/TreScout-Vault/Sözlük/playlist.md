---
title: "Playlist"
type: sozluk
category: "data"
aliases:
  - "Playlist"
url: "https://trescout.com/dictionary/playlist/"
---

# Playlist 

> [!NOTE] Tanım
> Dijital içeriklerin belirli bir sırayla veya temaya göre oynatılmak üzere bir araya getirildiği listedir.

## İngilizce Açıklama
It is a list where digital content is brought together to be played in a certain order or according to a theme.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/playlist/)*
