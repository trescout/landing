---
title: "Temperature"
type: sozluk
category: "ai"
aliases:
  - "Temperature"
url: "https://trescout.com/dictionary/temperature/"
---

# Temperature 

> [!NOTE] Tanım
> Yapay zekanın ürettiği cevapların yaratıcılık seviyesini belirleyen ayardır.

## İngilizce Açıklama
It is the setting that determines the creativity level of the answers produced by artificial intelligence.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/temperature/)*
