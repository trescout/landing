---
title: "Semantic Metadata"
type: sozluk
category: "data"
aliases:
  - "Semantic Metadata"
url: "https://trescout.com/dictionary/semantic-metadata/"
---

# Semantic Metadata 

> [!NOTE] Tanım
> Verinin sadece ne olduğunu değil, ne anlama geldiğini ve diğer verilerle bağını açıklayan etikettir.

## İngilizce Açıklama
It is a label that explains not only what the data is, but also what it means and its connection with other data.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/semantic-metadata/)*
