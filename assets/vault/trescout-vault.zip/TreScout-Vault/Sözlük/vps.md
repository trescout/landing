---
title: "VPS"
type: sozluk
category: "dev"
aliases:
  - "VPS"
  - "Virtual Private Server"
url: "https://trescout.com/dictionary/vps/"
---

# VPS (Virtual Private Server)

> [!NOTE] Tanım
> İnternet üzerindeki güçlü bir fiziksel sunucunun, size özel bir bilgisayar gibi kiralanarak kullanılmasıdır.

## İngilizce Açıklama
It is the use of a powerful physical server on the Internet by renting it as a private computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/vps/)*
