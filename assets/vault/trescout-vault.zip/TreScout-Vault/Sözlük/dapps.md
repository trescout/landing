---
title: "dApps"
type: sozluk
category: "dev"
aliases:
  - "dApps"
  - "Decentralized Applications"
url: "https://trescout.com/dictionary/dapps/"
---

# dApps (Decentralized Applications)

> [!NOTE] Tanım
> Merkezi bir otoriteye bağlı olmadan, blok zinciri üzerinde çalışan ve herkesin kullanımına açık olan dijital uygulamalardır.

## İngilizce Açıklama
They are digital applications that work on the blockchain and are open to everyone, without being dependent on a central authority.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dapps/)*
