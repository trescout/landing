---
title: "Agentic System"
type: sozluk
category: "ai"
aliases:
  - "Agentic System"
url: "https://trescout.com/dictionary/agentic-system/"
---

# Agentic System 

> [!NOTE] Tanım
> İnsan müdahalesi olmadan hedeflere ulaşmak için kendi başına karar alıp aksiyon geliştiren otonom yapılar.

## İngilizce Açıklama
Autonomous structures that make decisions and take action on their own to achieve goals without human intervention.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agentic-system/)*
