---
title: "Diff File Editing"
type: sozluk
category: "dev"
aliases:
  - "Diff File Editing"
url: "https://trescout.com/dictionary/diff-file-editing/"
---

# Diff File Editing 

> [!NOTE] Tanım
> Bir dosyanın tamamını değiştirmek yerine, sadece eski ve yeni sürüm arasındaki farkları (diff) uygulayarak güncelleme yapma yöntemidir.

## İngilizce Açıklama
It is a method of updating a file by applying only the differences (diffs) between the old and new version, instead of changing the entire file.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/diff-file-editing/)*
