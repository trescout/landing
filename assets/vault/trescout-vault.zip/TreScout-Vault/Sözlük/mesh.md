---
title: "Mesh"
type: sozluk
category: "dev"
aliases:
  - "Mesh"
url: "https://trescout.com/dictionary/mesh/"
---

# Mesh 

> [!NOTE] Tanım
> Birbirine bağlı çok sayıda cihazın veya hizmetin, merkezi bir noktaya ihtiyaç duymadan veri alışverişi yapması.

## İngilizce Açıklama
Multiple interconnected devices or services exchange data without the need for a central point.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/mesh/)*
