---
title: "Algorithmic Trading"
type: sozluk
category: "data"
aliases:
  - "Algorithmic Trading"
url: "https://trescout.com/dictionary/algorithmic-trading/"
---

# Algorithmic Trading 

> [!NOTE] Tanım
> Borsa ve finansal piyasalardaki alım-satım işlemlerinin, önceden belirlenmiş kurallar çerçevesinde yazılımlar tarafından otomatik yapılmasıdır.

## İngilizce Açıklama
Buying and selling transactions in the stock market and financial markets are carried out automatically by software within the framework of predetermined rules.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/algorithmic-trading/)*
