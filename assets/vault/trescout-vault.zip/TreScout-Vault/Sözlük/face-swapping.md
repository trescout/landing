---
title: "Face Swapping"
type: sozluk
category: "ai"
aliases:
  - "Face Swapping"
url: "https://trescout.com/dictionary/face-swapping/"
---

# Face Swapping 

> [!NOTE] Tanım
> Bir görüntüdeki veya videodaki yüzü, yapay zekâ kullanarak başka bir kişinin yüzüyle değiştirme işlemi.

## İngilizce Açıklama
The process of replacing a face in an image or video with the face of another person using artificial intelligence.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/face-swapping/)*
