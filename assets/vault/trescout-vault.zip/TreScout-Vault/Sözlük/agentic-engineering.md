---
title: "Agentic Engineering"
type: sozluk
category: "ai"
aliases:
  - "Agentic Engineering"
url: "https://trescout.com/dictionary/agentic-engineering/"
---

# Agentic Engineering 

> [!NOTE] Tanım
> Kendi kararlarını alıp hedefe ulaşabilen otonom yazılım sistemleri tasarlama disiplinidir.

## İngilizce Açıklama
It is the discipline of designing autonomous software systems that can make their own decisions and achieve their goals.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/agentic-engineering/)*
