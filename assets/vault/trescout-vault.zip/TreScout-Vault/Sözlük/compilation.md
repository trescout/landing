---
title: "Compilation"
type: sozluk
category: "dev"
aliases:
  - "Compilation"
url: "https://trescout.com/dictionary/compilation/"
---

# Compilation 

> [!NOTE] Tanım
> İnsan diline yakın yazılan kodların, bilgisayarın işlemcisinin anlayabileceği makine diline dönüştürülmesi sürecidir.

## İngilizce Açıklama
It is the process of converting codes written close to human language into machine language that the computer's processor can understand.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/compilation/)*
