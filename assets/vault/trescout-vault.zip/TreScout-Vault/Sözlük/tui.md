---
title: "TUI"
type: sozluk
category: "dev"
aliases:
  - "TUI"
  - "Text User Interface"
url: "https://trescout.com/dictionary/tui/"
---

# TUI (Text User Interface)

> [!NOTE] Tanım
> Grafiksel öğeler yerine sadece metin ve karakterlerle yönetilen ekran arayüzü.

## İngilizce Açıklama
On-screen interface driven only by text and characters instead of graphical elements.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/tui/)*
