---
title: "Multimodal Large Language Model"
type: sozluk
category: "ai"
aliases:
  - "Multimodal Large Language Model"
url: "https://trescout.com/dictionary/multimodal-large-language-model/"
---

# Multimodal Large Language Model 

> [!NOTE] Tanım
> Sadece metinle değil; görüntü, ses ve video gibi farklı veri türlerini de aynı anda işleyebilen gelişmiş yapay zekâ modelleridir.

## İngilizce Açıklama
Not just with text; They are advanced artificial intelligence models that can simultaneously process different types of data such as image, audio and video.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/multimodal-large-language-model/)*
