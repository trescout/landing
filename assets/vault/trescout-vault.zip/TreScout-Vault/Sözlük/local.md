---
title: "Local"
type: sozluk
category: "dev"
aliases:
  - "Local"
url: "https://trescout.com/dictionary/local/"
---

# Local 

> [!NOTE] Tanım
> Programların veya verilerin internete ihtiyaç duymadan, tamamen sizin cihazınızda çalışmasıdır.

## İngilizce Açıklama
It means that programs or data run entirely on your device, without the need for the Internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/local/)*
