---
title: "ADB"
type: sozluk
category: "dev"
aliases:
  - "ADB"
  - "Android Debug Bridge"
url: "https://trescout.com/dictionary/adb/"
---

# ADB (Android Debug Bridge)

> [!NOTE] Tanım
> Bilgisayarınız üzerinden Android cihazlara komut gönderip, yazılım yükleme veya sistem dosyalarını yönetme gibi işlemleri yapmanızı sağlayan bir köprüdür.

## İngilizce Açıklama
It is a bridge that allows you to send commands to Android devices via your computer and perform operations such as installing software or managing system files.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/adb/)*
