---
title: "Session Intelligence"
type: sozluk
category: "ai"
aliases:
  - "Session Intelligence"
url: "https://trescout.com/dictionary/session-intelligence/"
---

# Session Intelligence 

> [!NOTE] Tanım
> Kullanıcıların etkileşimlerini analiz ederek davranışlarını anlayan ve daha iyi deneyim sunmayı hedefleyen sistem.

## İngilizce Açıklama
A system that understands users' behavior by analyzing their interactions and aims to provide a better experience.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/session-intelligence/)*
