---
title: "Incremental Backup"
type: sozluk
category: "data"
aliases:
  - "Incremental Backup"
url: "https://trescout.com/dictionary/incremental-backup/"
---

# Incremental Backup 

> [!NOTE] Tanım
> Sadece en son yedeklemeden sonra değişen dosyaları kaydederek zamandan ve alandan tasarruf eden yedekleme yöntemidir.

## İngilizce Açıklama
It is a backup method that saves time and space by saving only the files that have changed since the last backup.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/incremental-backup/)*
