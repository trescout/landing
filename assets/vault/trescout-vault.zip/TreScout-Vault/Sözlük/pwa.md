---
title: "PWA"
type: sozluk
category: "dev"
aliases:
  - "PWA"
  - "Progressive Web App"
url: "https://trescout.com/dictionary/pwa/"
---

# PWA (Progressive Web App)

> [!NOTE] Tanım
> İnternet tarayıcısı üzerinden çalışan ancak telefonunuza veya bilgisayarınıza uygulama gibi yüklenebilen web sayfalarıdır.

## İngilizce Açıklama
These are web pages that work through an internet browser but can be installed on your phone or computer like an application.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/pwa/)*
