---
title: "Repository Checkout"
type: sozluk
category: "dev"
aliases:
  - "Repository Checkout"
url: "https://trescout.com/dictionary/repository-checkout/"
---

# Repository Checkout 

> [!NOTE] Tanım
> Bir yazılım projesinin tüm dosyalarını merkezi bir sunucudan kendi bilgisayarınıza kopyalama işlemidir.

## İngilizce Açıklama
It is the process of copying all the files of a software project from a central server to your own computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/repository-checkout/)*
