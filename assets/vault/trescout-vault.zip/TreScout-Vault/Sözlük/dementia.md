---
title: "Dementia"
type: sozluk
category: "ai"
aliases:
  - "Dementia"
url: "https://trescout.com/dictionary/dementia/"
---

# Dementia 

> [!NOTE] Tanım
> Beyindeki sinir hücrelerinin hasar görmesiyle hafıza, düşünme ve günlük yaşam becerilerinin ciddi şekilde zayıfladığı bir durumdur.

## İngilizce Açıklama
It is a condition in which memory, thinking and daily living skills are severely weakened due to damage to nerve cells in the brain.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/dementia/)*
