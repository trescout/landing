---
title: "Patch"
type: sozluk
category: "dev"
aliases:
  - "Patch"
url: "https://trescout.com/dictionary/patch/"
---

# Patch 

> [!NOTE] Tanım
> Yazılımdaki hataları düzeltmek veya eksikleri gidermek için uygulanan küçük güncelleme yamasıdır.

## İngilizce Açıklama
It is a small update patch applied to fix errors or eliminate deficiencies in the software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/patch/)*
