---
title: "PDF"
type: sozluk
category: "data"
aliases:
  - "PDF"
  - "Portable Document Format"
url: "https://trescout.com/dictionary/pdf/"
---

# PDF (Portable Document Format)

> [!NOTE] Tanım
> Hangi cihazda açılırsa açılsın biçimi bozulmadan görüntülenen dijital belge formatıdır.

## İngilizce Açıklama
It is a digital document format that is displayed without losing its format no matter what device it is opened on.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/pdf/)*
