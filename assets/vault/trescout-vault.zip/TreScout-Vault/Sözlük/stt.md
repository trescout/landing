---
title: "STT"
type: sozluk
category: "ai"
aliases:
  - "STT"
  - "Speech-to-Text"
url: "https://trescout.com/dictionary/stt/"
---

# STT (Speech-to-Text)

> [!NOTE] Tanım
> Konuşulan kelimeleri dinleyip bunları yazılı metne dönüştüren teknolojidir.

## İngilizce Açıklama
It is technology that listens to spoken words and converts them into written text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/stt/)*
