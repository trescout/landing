---
title: "Application"
type: sozluk
category: "dev"
aliases:
  - "Application"
url: "https://trescout.com/dictionary/application/"
---

# Application 

> [!NOTE] Tanım
> Bilgisayar, telefon veya tablet gibi cihazlarda belirli bir görevi yerine getirmek için tasarlanmış yazılım programıdır.

## İngilizce Açıklama
It is a software program designed to perform a specific task on devices such as computers, phones or tablets.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/application/)*
