---
title: "Memory API"
type: sozluk
category: "dev"
aliases:
  - "Memory API"
url: "https://trescout.com/dictionary/memory-api/"
---

# Memory API 

> [!NOTE] Tanım
> Yazılımların yapay zekâ hafızasına veri eklemesini veya mevcut bilgileri sorgulamasını sağlayan bağlantı noktası.

## İngilizce Açıklama
Port that allows software to add data to artificial intelligence memory or query existing information.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/memory-api/)*
