---
title: "Unit Testing"
type: sozluk
category: "dev"
aliases:
  - "Unit Testing"
url: "https://trescout.com/dictionary/unit-testing/"
---

# Unit Testing 

> [!NOTE] Tanım
> Yazılımın en küçük parçalarının tek başına doğru çalışıp çalışmadığını doğrulayan test yöntemidir.

## İngilizce Açıklama
It is a testing method that verifies whether the smallest parts of the software work correctly on their own.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/unit-testing/)*
