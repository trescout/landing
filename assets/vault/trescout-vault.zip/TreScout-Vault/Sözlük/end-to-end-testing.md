---
title: "End-to-End Testing"
type: sozluk
category: "dev"
aliases:
  - "End-to-End Testing"
  - "E2E Testing"
url: "https://trescout.com/dictionary/end-to-end-testing/"
---

# End-to-End Testing (E2E Testing)

> [!NOTE] Tanım
> Bir uygulamanın gerçek bir kullanıcı gibi baştan sona tüm işleyişinin doğrulanmasıdır.

## İngilizce Açıklama
It is the verification of the entire operation of an application from start to finish, just like a real user.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/end-to-end-testing/)*
