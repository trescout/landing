---
title: "Wordlists"
type: sozluk
category: "dev"
aliases:
  - "Wordlists"
url: "https://trescout.com/dictionary/wordlists/"
---

# Wordlists 

> [!NOTE] Tanım
> Sistemlere giriş denemeleri yapmak için kullanılan, sık tercih edilen kelimelerin ve şifrelerin bulunduğu listelerdir.

## İngilizce Açıklama
These are lists of frequently used words and passwords used to attempt to log into systems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/wordlists/)*
