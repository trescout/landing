---
title: "Git Push"
type: sozluk
category: "dev"
aliases:
  - "Git Push"
url: "https://trescout.com/dictionary/git-push/"
---

# Git Push 

> [!NOTE] Tanım
> Yerel bilgisayarınızda yaptığınız yazılım değişikliklerini internet üzerindeki ortak bir sunucuya yükleme işlemidir.

## İngilizce Açıklama
It is the process of uploading the software changes you make on your local computer to a shared server on the internet.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/git-push/)*
