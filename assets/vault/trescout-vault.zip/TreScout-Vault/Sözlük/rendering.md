---
title: "Rendering"
type: sozluk
category: "dev"
aliases:
  - "Rendering"
url: "https://trescout.com/dictionary/rendering/"
---

# Rendering 

> [!NOTE] Tanım
> Bilgisayarın ham verileri işleyerek ekranda gördüğümüz görsel veya grafik haline getirme süreci.

## İngilizce Açıklama
The process of a computer processing raw data and turning it into a visual or graphic that we see on the screen.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/rendering/)*
