---
title: "Cloud Native"
type: sozluk
category: "dev"
aliases:
  - "Cloud Native"
url: "https://trescout.com/dictionary/cloud-native/"
---

# Cloud Native 

> [!NOTE] Tanım
> Uygulamaların bulut ortamında en yüksek verimle çalışacak şekilde tasarlanması ve yönetilmesi yaklaşımıdır.

## İngilizce Açıklama
It is an approach to designing and managing applications to run with the highest efficiency in the cloud environment.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/cloud-native/)*
