---
title: "Cyber Capabilities"
type: sozluk
category: "dev"
aliases:
  - "Cyber Capabilities"
url: "https://trescout.com/dictionary/cyber-capabilities/"
---

# Cyber Capabilities 

> [!NOTE] Tanım
> Dijital sistemleri korumak veya bu sistemlere müdahale etmek için kullanılan teknik yetenekler ve araçlardır.

## İngilizce Açıklama
They are technical capabilities and tools used to protect or intervene in digital systems.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/cyber-capabilities/)*
