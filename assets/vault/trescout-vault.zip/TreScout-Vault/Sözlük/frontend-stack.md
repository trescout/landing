---
title: "Frontend Stack"
type: sozluk
category: "dev"
aliases:
  - "Frontend Stack"
url: "https://trescout.com/dictionary/frontend-stack/"
---

# Frontend Stack 

> [!NOTE] Tanım
> Bir web sitesinin veya uygulamanın kullanıcı tarafından görünen kısmını oluşturmak için kullanılan yazılım araçları bütünüdür.

## İngilizce Açıklama
It is a set of software tools used to create the user-visible part of a website or application.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/frontend-stack/)*
