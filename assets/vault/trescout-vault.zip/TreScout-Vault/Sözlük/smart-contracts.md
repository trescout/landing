---
title: "Smart Contracts"
type: sozluk
category: "dev"
aliases:
  - "Smart Contracts"
url: "https://trescout.com/dictionary/smart-contracts/"
---

# Smart Contracts 

> [!NOTE] Tanım
> Belirli koşullar sağlandığında otomatik olarak çalışan ve aracı gerektirmeyen dijital sözleşmelerdir.

## İngilizce Açıklama
They are digital contracts that work automatically when certain conditions are met and do not require an intermediary.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/smart-contracts/)*
