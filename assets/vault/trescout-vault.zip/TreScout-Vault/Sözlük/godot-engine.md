---
title: "Godot Engine"
type: sozluk
category: "dev"
aliases:
  - "Godot Engine"
url: "https://trescout.com/dictionary/godot-engine/"
---

# Godot Engine 

> [!NOTE] Tanım
> Oyun geliştirmek için kullanılan, tamamen ücretsiz ve açık kaynaklı bir yazılım platformudur.

## İngilizce Açıklama
It is a completely free and open source software platform used for game development.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/godot-engine/)*
