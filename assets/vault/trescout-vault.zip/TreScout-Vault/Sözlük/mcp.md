---
title: "MCP"
type: sozluk
category: "ai"
aliases:
  - "MCP"
  - "Model Context Protocol"
url: "https://trescout.com/dictionary/mcp/"
---

# MCP (Model Context Protocol)

> [!NOTE] Tanım
> Yapay zekâ modellerinin dış dünyadaki verilerle güvenli şekilde konuşmasını sağlayan standarttır.

## İngilizce Açıklama
It is the standard that enables artificial intelligence models to talk securely with data from the outside world.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/mcp/)*
