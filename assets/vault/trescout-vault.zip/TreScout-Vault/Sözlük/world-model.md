---
title: "World Model"
type: sozluk
category: "ai"
aliases:
  - "World Model"
url: "https://trescout.com/dictionary/world-model/"
---

# World Model 

> [!NOTE] Tanım
> Yapay zekanın fiziksel dünyanın nasıl işlediğini anlamasını sağlayan sistemdir.

## İngilizce Açıklama
It is the system that allows artificial intelligence to understand how the physical world works.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/world-model/)*
