---
title: "ARQ"
type: sozluk
category: "dev"
aliases:
  - "ARQ"
  - "Automatic Repeat Request"
url: "https://trescout.com/dictionary/arq/"
---

# ARQ (Automatic Repeat Request)

> [!NOTE] Tanım
> Veri iletimi sırasında hata oluştuğunda bilginin otomatik olarak tekrar gönderilmesini sağlayan hata kontrol mekanizmasıdır.

## İngilizce Açıklama
It is an error control mechanism that ensures that information is automatically re-sent when an error occurs during data transmission.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/arq/)*
