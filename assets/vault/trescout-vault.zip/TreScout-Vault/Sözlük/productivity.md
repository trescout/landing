---
title: "Productivity"
type: sozluk
category: "ai"
aliases:
  - "Productivity"
url: "https://trescout.com/dictionary/productivity/"
---

# Productivity 

> [!NOTE] Tanım
> Belli bir zaman dilimi içerisinde daha kaliteli ve daha fazla iş üretme kapasitesidir.

## İngilizce Açıklama
It is the capacity to produce higher quality and more work within a certain period of time.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/productivity/)*
