---
title: "SBOM"
type: sozluk
category: "dev"
aliases:
  - "SBOM"
  - "Software Bill of Materials"
url: "https://trescout.com/dictionary/sbom/"
---

# SBOM (Software Bill of Materials)

> [!NOTE] Tanım
> Bir yazılımın içinde kullanılan tüm açık kaynaklı kütüphanelerin ve bileşenlerin listelendiği bir envanter belgesidir.

## İngilizce Açıklama
It is an inventory document that lists all open source libraries and components used in a software.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/sbom/)*
