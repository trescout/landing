---
title: "Thread-safety"
type: sozluk
category: "dev"
aliases:
  - "Thread-safety"
url: "https://trescout.com/dictionary/thread-safety/"
---

# Thread-safety 

> [!NOTE] Tanım
> Bir programın aynı anda birden fazla işlem yaparken verilerin bozulmasını engelleyen güvenlik özelliği.

## İngilizce Açıklama
A security feature of a program that prevents data from being corrupted when performing multiple operations at the same time.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/thread-safety/)*
