---
title: "Continual Learning"
type: sozluk
category: "ai"
aliases:
  - "Continual Learning"
url: "https://trescout.com/dictionary/continual-learning/"
---

# Continual Learning 

> [!NOTE] Tanım
> Yapay zekânın yeni bilgiler öğrenirken eski bilgilerini unutmadan sürekli güncel kalma yeteneğidir.

## İngilizce Açıklama
It is the ability of artificial intelligence to constantly stay updated without forgetting old information while learning new information.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/continual-learning/)*
