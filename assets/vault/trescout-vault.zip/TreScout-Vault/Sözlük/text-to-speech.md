---
title: "Text-to-Speech"
type: sozluk
category: "ai"
aliases:
  - "Text-to-Speech"
  - "TTS"
url: "https://trescout.com/dictionary/text-to-speech/"
---

# Text-to-Speech (TTS)

> [!NOTE] Tanım
> Yazılı metinlerin yapay zekâ tarafından insan sesiyle seslendirilmesidir.

## İngilizce Açıklama
It is the vocalization of written texts with a human voice by artificial intelligence.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/text-to-speech/)*
