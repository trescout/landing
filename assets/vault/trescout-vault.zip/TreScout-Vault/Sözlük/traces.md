---
title: "Traces"
type: sozluk
category: "dev"
aliases:
  - "Traces"
url: "https://trescout.com/dictionary/traces/"
---

# Traces 

> [!NOTE] Tanım
> Bir işlemin sistem içinde hangi aşamalardan geçtiğini adım adım gösteren izleme kayıtlarıdır.

## İngilizce Açıklama
These are monitoring records that show step by step through which stages a transaction goes through in the system.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/traces/)*
