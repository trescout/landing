---
title: "CI/CD"
type: sozluk
category: "dev"
aliases:
  - "CI/CD"
  - "Continuous Integration / Continuous Deployment"
url: "https://trescout.com/dictionary/ci-cd/"
---

# CI/CD (Continuous Integration / Continuous Deployment)

> [!NOTE] Tanım
> Yazılım güncellemelerinin otomatik olarak test edilip yayına alınmasını sağlayan süreçtir.

## İngilizce Açıklama
It is the process that ensures that software updates are automatically tested and released.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/ci-cd/)*
