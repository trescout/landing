---
title: "AI Agent Skill"
type: sozluk
category: "ai"
aliases:
  - "AI Agent Skill"
url: "https://trescout.com/dictionary/ai-agent-skill/"
---

# AI Agent Skill 

> [!NOTE] Tanım
> Yapay zekâ temsilcisinin bir işi tamamlamak için kullanabileceği, internette arama yapmak veya dosya düzenlemek gibi özel becerilerdir.

## İngilizce Açıklama
They are specific skills that an AI agent can use to complete a job, such as searching the internet or organizing a file.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/ai-agent-skill/)*
