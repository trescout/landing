---
title: "Container"
type: sozluk
category: "dev"
aliases:
  - "Container"
url: "https://trescout.com/dictionary/container/"
---

# Container 

> [!NOTE] Tanım
> Bir yazılımın çalışması için gereken her şeyi içinde barındıran ve her bilgisayarda aynı şekilde çalışmasını sağlayan taşınabilir bir kutudur.

## İngilizce Açıklama
It is a portable box that contains everything required for a software to run and ensures that it works the same on every computer.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/container/)*
