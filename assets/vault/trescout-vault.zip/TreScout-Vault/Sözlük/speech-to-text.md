---
title: "Speech-to-Text"
type: sozluk
category: "ai"
aliases:
  - "Speech-to-Text"
url: "https://trescout.com/dictionary/speech-to-text/"
---

# Speech-to-Text 

> [!NOTE] Tanım
> Söylenen sözleri dinleyip bunları otomatik olarak yazılı metne dönüştüren teknolojidir.

## İngilizce Açıklama
It is technology that listens to spoken words and automatically converts them into written text.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/speech-to-text/)*
