---
title: "LoRA"
type: sozluk
category: "ai"
aliases:
  - "LoRA"
  - "Low-Rank Adaptation"
url: "https://trescout.com/dictionary/lora/"
---

# LoRA (Low-Rank Adaptation)

> [!NOTE] Tanım
> Büyük bir yapay zekâ modelini, tümünü değiştirmeden sadece küçük bir kısmını güncelleyerek belirli bir konuda uzmanlaştırma tekniğidir.

## İngilizce Açıklama
It is a technique of making a large artificial intelligence model specialize in a particular subject by updating only a small part of it without changing the entire model.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/lora/)*
