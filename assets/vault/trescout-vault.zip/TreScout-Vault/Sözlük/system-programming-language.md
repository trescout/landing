---
title: "System Programming Language"
type: sozluk
category: "dev"
aliases:
  - "System Programming Language"
url: "https://trescout.com/dictionary/system-programming-language/"
---

# System Programming Language 

> [!NOTE] Tanım
> İşletim sistemi veya donanım sürücüsü gibi temel seviyede yazılımlar geliştirmek için kullanılan güçlü dildir.

## İngilizce Açıklama
It is a powerful language used to develop basic level software such as an operating system or hardware driver.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/system-programming-language/)*
