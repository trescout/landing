---
title: "Google Cloud"
type: sozluk
category: "dev"
aliases:
  - "Google Cloud"
  - "Google Cloud Platform"
url: "https://trescout.com/dictionary/google-cloud/"
---

# Google Cloud (Google Cloud Platform)

> [!NOTE] Tanım
> Google tarafından sunulan, internet üzerinden veri depolama ve uygulama çalıştırma hizmetleri platformudur.

## İngilizce Açıklama
It is a platform for data storage and application execution services over the internet, offered by Google.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/google-cloud/)*
