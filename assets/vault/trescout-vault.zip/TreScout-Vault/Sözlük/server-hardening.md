---
title: "Server Hardening"
type: sozluk
category: "dev"
aliases:
  - "Server Hardening"
url: "https://trescout.com/dictionary/server-hardening/"
---

# Server Hardening 

> [!NOTE] Tanım
> Bir sunucudaki gereksiz özellikleri kapatarak ve güvenlik ayarlarını sıkılaştırarak saldırı riskini azaltma işlemidir.

## İngilizce Açıklama
It is the process of reducing the risk of attack by turning off unnecessary features on a server and tightening security settings.

---
*Kaynak: [TreScout Sözlük](https://trescout.com/dictionary/server-hardening/)*
